import React, { useState } from 'react';
import { BrowserRouter as Router, Routes, Route, Navigate } from 'react-router-dom';
import Login from './components/Login';
import Dashboard from './components/Dashboard';
import PassportApplication from './components/PassportApplication';
import Appointments from './components/Appointments';
import Payments from './components/Payments';
import DocumentManagement from './components/DocumentManagement';
import ApplicantManagement from './components/ApplicantManagement';
import Administration from './components/Administration';
import Reports from './components/Reports';
import AuditLogs from './components/AuditLogs';
import Settings from './components/Settings';
import Layout from './components/Layout';
import { AuthProvider, useAuth } from './contexts/AuthContext';

function AppRoutes() {
  const { user } = useAuth();

  if (!user) {
    return <Login />;
  }

  return (
    <Layout>
      <Routes>
        <Route path="/" element={<Dashboard />} />
        <Route path="/dashboard" element={<Dashboard />} />
        <Route path="/passport-application" element={<PassportApplication />} />
        <Route path="/appointments" element={<Appointments />} />
        <Route path="/payments" element={<Payments />} />
        <Route path="/documents" element={<DocumentManagement />} />
        <Route path="/applicants" element={<ApplicantManagement />} />
        <Route path="/administration" element={<Administration />} />
        <Route path="/reports" element={<Reports />} />
        <Route path="/audit-logs" element={<AuditLogs />} />
        <Route path="/settings" element={<Settings />} />
        <Route path="*" element={<Navigate to="/dashboard" replace />} />
      </Routes>
    </Layout>
  );
}

function App() {
  return (
    <AuthProvider>
      <Router>
        <div className="min-h-screen bg-gray-50">
          <AppRoutes />
        </div>
      </Router>
    </AuthProvider>
  );
}

export default App;