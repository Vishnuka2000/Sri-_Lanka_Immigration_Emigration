import React, { useState } from 'react';
import { 
  FileText, 
  CheckCircle, 
  XCircle, 
  Clock, 
  Eye, 
  Download, 
  Upload,
  MessageSquare,
  AlertTriangle,
  Filter
} from 'lucide-react';

const DocumentManagement = () => {
  const [selectedStatus, setSelectedStatus] = useState('all');
  const [selectedApplication, setSelectedApplication] = useState(null);
  const [verificationNote, setVerificationNote] = useState('');

  const documents = [
    {
      id: 1,
      applicationRef: 'APP-2025-001234',
      applicant: 'Kamal Perera',
      documentType: 'NIC Copy',
      fileName: 'nic_kamal_perera.pdf',
      uploadDate: '2025-01-10',
      status: 'pending',
      size: '2.3 MB',
      notes: '',
    },
    {
      id: 2,
      applicationRef: 'APP-2025-001234',
      applicant: 'Kamal Perera',
      documentType: 'Birth Certificate',
      fileName: 'birth_cert_kamal.pdf',
      uploadDate: '2025-01-10',
      status: 'verified',
      size: '1.8 MB',
      notes: 'Document verified successfully',
    },
    {
      id: 3,
      applicationRef: 'APP-2025-001235',
      applicant: 'Sita Fernando',
      documentType: 'Previous Passport',
      fileName: 'old_passport_sita.jpg',
      uploadDate: '2025-01-09',
      status: 'rejected',
      size: '3.1 MB',
      notes: 'Image quality is poor. Please upload a clearer copy.',
    },
    {
      id: 4,
      applicationRef: 'APP-2025-001236',
      applicant: 'Ravi Silva',
      documentType: 'Police Report',
      fileName: 'police_report_ravi.pdf',
      uploadDate: '2025-01-09',
      status: 'pending',
      size: '1.2 MB',
      notes: '',
    },
    {
      id: 5,
      applicationRef: 'APP-2025-001237',
      applicant: 'Nimal Jayasinghe',
      documentType: 'Passport Photo',
      fileName: 'photo_nimal.jpg',
      uploadDate: '2025-01-08',
      status: 'verified',
      size: '0.8 MB',
      notes: 'Photo meets all requirements',
    },
  ];

  const filteredDocuments = selectedStatus === 'all' 
    ? documents 
    : documents.filter(doc => doc.status === selectedStatus);

  const handleVerification = (documentId: number, status: 'verified' | 'rejected') => {
    if (status === 'rejected' && !verificationNote.trim()) {
      alert('Please provide a reason for rejection');
      return;
    }

    const document = documents.find(doc => doc.id === documentId);
    if (document) {
      alert(`Document ${document.fileName} has been ${status}${verificationNote ? ` with note: ${verificationNote}` : ''}`);
      setVerificationNote('');
      setSelectedApplication(null);
    }
  };

  const requestAdditionalDocument = (applicationRef: string) => {
    const message = prompt('What additional document is required?');
    if (message) {
      alert(`Request sent to applicant for additional document: ${message}`);
    }
  };

  const downloadDocument = (fileName: string) => {
    alert(`Downloading ${fileName}`);
  };

  const viewDocument = (fileName: string) => {
    alert(`Opening ${fileName} in viewer`);
  };

  const getStatusIcon = (status: string) => {
    switch (status) {
      case 'verified':
        return <CheckCircle className="w-5 h-5 text-emerald-600" />;
      case 'rejected':
        return <XCircle className="w-5 h-5 text-red-600" />;
      case 'pending':
        return <Clock className="w-5 h-5 text-amber-600" />;
      default:
        return <FileText className="w-5 h-5 text-gray-400" />;
    }
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'verified':
        return 'bg-emerald-100 text-emerald-800';
      case 'rejected':
        return 'bg-red-100 text-red-800';
      case 'pending':
        return 'bg-amber-100 text-amber-800';
      default:
        return 'bg-gray-100 text-gray-800';
    }
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex justify-between items-center">
        <div>
          <h1 className="text-2xl font-bold text-gray-900">Document Management</h1>
          <p className="text-gray-600">Review and verify uploaded documents</p>
        </div>
        
        <div className="flex items-center space-x-4">
          <div className="flex items-center space-x-2">
            <Filter className="w-4 h-4 text-gray-400" />
            <select
              value={selectedStatus}
              onChange={(e) => setSelectedStatus(e.target.value)}
              className="border border-gray-300 rounded-lg px-3 py-2 text-sm focus:ring-2 focus:ring-blue-500 focus:border-transparent"
            >
              <option value="all">All Documents</option>
              <option value="pending">Pending Review</option>
              <option value="verified">Verified</option>
              <option value="rejected">Rejected</option>
            </select>
          </div>
        </div>
      </div>

      {/* Statistics */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
        <div className="bg-white rounded-xl shadow-sm p-6">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm font-medium text-gray-600">Total Documents</p>
              <p className="text-2xl font-bold text-gray-900">{documents.length}</p>
            </div>
            <FileText className="w-8 h-8 text-blue-500" />
          </div>
        </div>
        
        <div className="bg-white rounded-xl shadow-sm p-6">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm font-medium text-gray-600">Pending Review</p>
              <p className="text-2xl font-bold text-amber-600">
                {documents.filter(doc => doc.status === 'pending').length}
              </p>
            </div>
            <Clock className="w-8 h-8 text-amber-500" />
          </div>
        </div>
        
        <div className="bg-white rounded-xl shadow-sm p-6">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm font-medium text-gray-600">Verified</p>
              <p className="text-2xl font-bold text-emerald-600">
                {documents.filter(doc => doc.status === 'verified').length}
              </p>
            </div>
            <CheckCircle className="w-8 h-8 text-emerald-500" />
          </div>
        </div>
        
        <div className="bg-white rounded-xl shadow-sm p-6">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm font-medium text-gray-600">Rejected</p>
              <p className="text-2xl font-bold text-red-600">
                {documents.filter(doc => doc.status === 'rejected').length}
              </p>
            </div>
            <XCircle className="w-8 h-8 text-red-500" />
          </div>
        </div>
      </div>

      {/* Documents List */}
      <div className="bg-white rounded-xl shadow-sm">
        <div className="p-6 border-b border-gray-200">
          <h2 className="text-lg font-semibold text-gray-900">Documents for Review</h2>
        </div>
        
        <div className="divide-y divide-gray-200">
          {filteredDocuments.map((document) => (
            <div key={document.id} className="p-6 hover:bg-gray-50 transition-colors">
              <div className="flex items-center justify-between">
                <div className="flex-1">
                  <div className="flex items-center space-x-4 mb-3">
                    <div className="flex items-center space-x-2">
                      {getStatusIcon(document.status)}
                      <span className="font-medium text-gray-900">{document.documentType}</span>
                    </div>
                    <span className={`px-2 py-1 text-xs font-medium rounded-full ${getStatusColor(document.status)}`}>
                      {document.status.charAt(0).toUpperCase() + document.status.slice(1)}
                    </span>
                  </div>
                  
                  <div className="grid grid-cols-1 md:grid-cols-3 gap-4 text-sm text-gray-600 mb-3">
                    <div>
                      <span className="font-medium">Application:</span> {document.applicationRef}
                    </div>
                    <div>
                      <span className="font-medium">Applicant:</span> {document.applicant}
                    </div>
                    <div>
                      <span className="font-medium">Upload Date:</span> {document.uploadDate}
                    </div>
                  </div>
                  
                  <div className="flex items-center space-x-4 text-sm text-gray-600 mb-3">
                    <span><span className="font-medium">File:</span> {document.fileName}</span>
                    <span><span className="font-medium">Size:</span> {document.size}</span>
                  </div>
                  
                  {document.notes && (
                    <div className="bg-gray-50 border border-gray-200 rounded-lg p-3 mb-3">
                      <div className="flex items-start space-x-2">
                        <MessageSquare className="w-4 h-4 text-gray-400 mt-0.5" />
                        <div>
                          <p className="text-sm font-medium text-gray-900">Notes:</p>
                          <p className="text-sm text-gray-600">{document.notes}</p>
                        </div>
                      </div>
                    </div>
                  )}
                </div>
                
                <div className="flex items-center space-x-2 ml-6">
                  <button
                    onClick={() => viewDocument(document.fileName)}
                    className="p-2 text-blue-600 hover:bg-blue-50 rounded-lg transition-colors"
                    title="View Document"
                  >
                    <Eye className="w-4 h-4" />
                  </button>
                  
                  <button
                    onClick={() => downloadDocument(document.fileName)}
                    className="p-2 text-gray-600 hover:bg-gray-50 rounded-lg transition-colors"
                    title="Download Document"
                  >
                    <Download className="w-4 h-4" />
                  </button>
                  
                  {document.status === 'pending' && (
                    <>
                      <button
                        onClick={() => handleVerification(document.id, 'verified')}
                        className="px-3 py-1 bg-emerald-600 text-white text-sm rounded-lg hover:bg-emerald-700 transition-colors"
                      >
                        Verify
                      </button>
                      
                      <button
                        onClick={() => setSelectedApplication(document.id)}
                        className="px-3 py-1 bg-red-600 text-white text-sm rounded-lg hover:bg-red-700 transition-colors"
                      >
                        Reject
                      </button>
                    </>
                  )}
                  
                  <button
                    onClick={() => requestAdditionalDocument(document.applicationRef)}
                    className="p-2 text-amber-600 hover:bg-amber-50 rounded-lg transition-colors"
                    title="Request Additional Document"
                  >
                    <Upload className="w-4 h-4" />
                  </button>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Rejection Modal */}
      {selectedApplication && (
        <div className="fixed inset-0 bg-gray-600 bg-opacity-50 flex items-center justify-center z-50">
          <div className="bg-white rounded-xl shadow-xl max-w-md w-full mx-4">
            <div className="p-6 border-b border-gray-200">
              <div className="flex items-center space-x-3">
                <AlertTriangle className="w-6 h-6 text-red-600" />
                <h2 className="text-xl font-semibold text-gray-900">Reject Document</h2>
              </div>
            </div>
            
            <div className="p-6">
              <p className="text-gray-600 mb-4">
                Please provide a reason for rejecting this document. This will help the applicant understand what needs to be corrected.
              </p>
              
              <textarea
                value={verificationNote}
                onChange={(e) => setVerificationNote(e.target.value)}
                className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                rows={4}
                placeholder="Enter reason for rejection..."
                required
              />
            </div>
            
            <div className="p-6 border-t border-gray-200 flex justify-end space-x-4">
              <button
                onClick={() => {
                  setSelectedApplication(null);
                  setVerificationNote('');
                }}
                className="px-4 py-2 text-gray-600 hover:text-gray-800 transition-colors"
              >
                Cancel
              </button>
              <button
                onClick={() => handleVerification(selectedApplication, 'rejected')}
                className="bg-red-600 text-white px-6 py-2 rounded-lg hover:bg-red-700 transition-colors"
              >
                Reject Document
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default DocumentManagement;