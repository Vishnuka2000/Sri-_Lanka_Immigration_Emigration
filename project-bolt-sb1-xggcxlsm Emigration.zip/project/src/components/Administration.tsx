import React, { useState } from 'react';
import { Building2, Users, Shield, Settings, Plus, CreditCard as Edit, Trash2, MapPin, Clock, Phone, Mail } from 'lucide-react';

const Administration = () => {
  const [activeTab, setActiveTab] = useState('offices');
  const [showAddForm, setShowAddForm] = useState(false);
  const [formType, setFormType] = useState('');

  const offices = [
    {
      id: 1,
      name: 'Colombo Main Office',
      address: '41, Ananda Rajakaruna Mawatha, Colombo 10',
      phone: '+94 11 532 9200',
      email: 'colombo@immigration.gov.lk',
      hours: '8:30 AM - 4:30 PM',
      capacity: 200,
      status: 'active',
    },
    {
      id: 2,
      name: 'Kandy Branch',
      address: 'Temple Street, Kandy',
      phone: '+94 81 222 3456',
      email: 'kandy@immigration.gov.lk',
      hours: '8:30 AM - 4:30 PM',
      capacity: 100,
      status: 'active',
    },
    {
      id: 3,
      name: 'Galle Branch',
      address: 'Fort, Galle',
      phone: '+94 91 234 5678',
      email: 'galle@immigration.gov.lk',
      hours: '8:30 AM - 4:30 PM',
      capacity: 80,
      status: 'active',
    },
  ];

  const officers = [
    {
      id: 1,
      name: 'Priya Wickramasinghe',
      email: 'priya@immigration.gov.lk',
      phone: '+94 77 123 4567',
      designation: 'Senior Immigration Officer',
      branch: 'Colombo Main Office',
      role: 'officer',
      status: 'active',
      joinDate: '2020-03-15',
    },
    {
      id: 2,
      name: 'Sunil Rathnayake',
      email: 'sunil@immigration.gov.lk',
      phone: '+94 71 987 6543',
      designation: 'Document Verification Officer',
      branch: 'Kandy Branch',
      role: 'officer',
      status: 'active',
      joinDate: '2021-07-20',
    },
    {
      id: 3,
      name: 'Chamari Dissanayake',
      email: 'chamari@immigration.gov.lk',
      phone: '+94 76 555 0123',
      designation: 'System Administrator',
      branch: 'Colombo Main Office',
      role: 'admin',
      status: 'active',
      joinDate: '2019-11-10',
    },
  ];

  const designations = [
    { id: 1, title: 'Senior Immigration Officer', level: 'Senior', permissions: ['verify', 'approve', 'reject'] },
    { id: 2, title: 'Immigration Officer', level: 'Mid', permissions: ['verify', 'process'] },
    { id: 3, title: 'Document Verification Officer', level: 'Junior', permissions: ['verify'] },
    { id: 4, title: 'System Administrator', level: 'Admin', permissions: ['all'] },
  ];

  const workflowStatuses = [
    { id: 1, name: 'Submitted', order: 1, description: 'Application submitted by applicant' },
    { id: 2, name: 'Documents Verified', order: 2, description: 'Documents reviewed and verified' },
    { id: 3, name: 'Police Check', order: 3, description: 'Background verification in progress' },
    { id: 4, name: 'Approved', order: 4, description: 'Application approved for processing' },
    { id: 5, name: 'Printed', order: 5, description: 'Passport printed and ready' },
    { id: 6, name: 'Dispatched/Collected', order: 6, description: 'Passport delivered or collected' },
  ];

  const handleAdd = (type: string) => {
    setFormType(type);
    setShowAddForm(true);
  };

  const handleEdit = (type: string, id: number) => {
    alert(`Edit ${type} with ID: ${id}`);
  };

  const handleDelete = (type: string, id: number) => {
    if (confirm(`Are you sure you want to delete this ${type}?`)) {
      alert(`Deleted ${type} with ID: ${id}`);
    }
  };

  const renderOffices = () => (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <h2 className="text-lg font-semibold text-gray-900">Offices & Branches</h2>
        <button
          onClick={() => handleAdd('office')}
          className="flex items-center space-x-2 bg-blue-600 text-white px-4 py-2 rounded-lg hover:bg-blue-700 transition-colors"
        >
          <Plus className="w-4 h-4" />
          <span>Add Office</span>
        </button>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {offices.map((office) => (
          <div key={office.id} className="bg-white border border-gray-200 rounded-xl p-6 hover:shadow-md transition-shadow">
            <div className="flex items-center justify-between mb-4">
              <h3 className="text-lg font-medium text-gray-900">{office.name}</h3>
              <span className={`px-2 py-1 text-xs font-medium rounded-full ${
                office.status === 'active' ? 'bg-emerald-100 text-emerald-800' : 'bg-gray-100 text-gray-800'
              }`}>
                {office.status}
              </span>
            </div>
            
            <div className="space-y-3 text-sm text-gray-600">
              <div className="flex items-start space-x-2">
                <MapPin className="w-4 h-4 mt-0.5" />
                <span>{office.address}</span>
              </div>
              <div className="flex items-center space-x-2">
                <Phone className="w-4 h-4" />
                <span>{office.phone}</span>
              </div>
              <div className="flex items-center space-x-2">
                <Mail className="w-4 h-4" />
                <span>{office.email}</span>
              </div>
              <div className="flex items-center space-x-2">
                <Clock className="w-4 h-4" />
                <span>{office.hours}</span>
              </div>
              <div className="flex items-center space-x-2">
                <Users className="w-4 h-4" />
                <span>Capacity: {office.capacity} per day</span>
              </div>
            </div>
            
            <div className="flex justify-end space-x-2 mt-4 pt-4 border-t border-gray-200">
              <button
                onClick={() => handleEdit('office', office.id)}
                className="p-2 text-gray-600 hover:text-blue-600 hover:bg-blue-50 rounded-lg transition-colors"
              >
                <Edit className="w-4 h-4" />
              </button>
              <button
                onClick={() => handleDelete('office', office.id)}
                className="p-2 text-gray-600 hover:text-red-600 hover:bg-red-50 rounded-lg transition-colors"
              >
                <Trash2 className="w-4 h-4" />
              </button>
            </div>
          </div>
        ))}
      </div>
    </div>
  );

  const renderOfficers = () => (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <h2 className="text-lg font-semibold text-gray-900">Officers & Staff</h2>
        <button
          onClick={() => handleAdd('officer')}
          className="flex items-center space-x-2 bg-blue-600 text-white px-4 py-2 rounded-lg hover:bg-blue-700 transition-colors"
        >
          <Plus className="w-4 h-4" />
          <span>Add Officer</span>
        </button>
      </div>

      <div className="bg-white rounded-xl shadow-sm overflow-hidden">
        <table className="w-full">
          <thead className="bg-gray-50">
            <tr>
              <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Officer</th>
              <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Designation</th>
              <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Branch</th>
              <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Role</th>
              <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Status</th>
              <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Actions</th>
            </tr>
          </thead>
          <tbody className="bg-white divide-y divide-gray-200">
            {officers.map((officer) => (
              <tr key={officer.id} className="hover:bg-gray-50">
                <td className="px-6 py-4 whitespace-nowrap">
                  <div>
                    <div className="text-sm font-medium text-gray-900">{officer.name}</div>
                    <div className="text-sm text-gray-500">{officer.email}</div>
                    <div className="text-sm text-gray-500">{officer.phone}</div>
                  </div>
                </td>
                <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-900">
                  {officer.designation}
                </td>
                <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-900">
                  {officer.branch}
                </td>
                <td className="px-6 py-4 whitespace-nowrap">
                  <span className={`px-2 py-1 text-xs font-medium rounded-full ${
                    officer.role === 'admin' 
                      ? 'bg-purple-100 text-purple-800'
                      : 'bg-blue-100 text-blue-800'
                  }`}>
                    {officer.role}
                  </span>
                </td>
                <td className="px-6 py-4 whitespace-nowrap">
                  <span className={`px-2 py-1 text-xs font-medium rounded-full ${
                    officer.status === 'active' 
                      ? 'bg-emerald-100 text-emerald-800'
                      : 'bg-gray-100 text-gray-800'
                  }`}>
                    {officer.status}
                  </span>
                </td>
                <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                  <div className="flex space-x-2">
                    <button
                      onClick={() => handleEdit('officer', officer.id)}
                      className="text-blue-600 hover:text-blue-800"
                    >
                      <Edit className="w-4 h-4" />
                    </button>
                    <button
                      onClick={() => handleDelete('officer', officer.id)}
                      className="text-red-600 hover:text-red-800"
                    >
                      <Trash2 className="w-4 h-4" />
                    </button>
                  </div>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );

  const renderDesignations = () => (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <h2 className="text-lg font-semibold text-gray-900">Designations & Roles</h2>
        <button
          onClick={() => handleAdd('designation')}
          className="flex items-center space-x-2 bg-blue-600 text-white px-4 py-2 rounded-lg hover:bg-blue-700 transition-colors"
        >
          <Plus className="w-4 h-4" />
          <span>Add Designation</span>
        </button>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        {designations.map((designation) => (
          <div key={designation.id} className="bg-white border border-gray-200 rounded-xl p-6">
            <div className="flex items-center justify-between mb-4">
              <h3 className="text-lg font-medium text-gray-900">{designation.title}</h3>
              <span className={`px-2 py-1 text-xs font-medium rounded-full ${
                designation.level === 'Admin' 
                  ? 'bg-purple-100 text-purple-800'
                  : designation.level === 'Senior'
                  ? 'bg-blue-100 text-blue-800'
                  : designation.level === 'Mid'
                  ? 'bg-emerald-100 text-emerald-800'
                  : 'bg-amber-100 text-amber-800'
              }`}>
                {designation.level}
              </span>
            </div>
            
            <div className="mb-4">
              <h4 className="text-sm font-medium text-gray-700 mb-2">Permissions:</h4>
              <div className="flex flex-wrap gap-2">
                {designation.permissions.map((permission, index) => (
                  <span key={index} className="px-2 py-1 bg-gray-100 text-gray-700 text-xs rounded">
                    {permission}
                  </span>
                ))}
              </div>
            </div>
            
            <div className="flex justify-end space-x-2 pt-4 border-t border-gray-200">
              <button
                onClick={() => handleEdit('designation', designation.id)}
                className="p-2 text-gray-600 hover:text-blue-600 hover:bg-blue-50 rounded-lg transition-colors"
              >
                <Edit className="w-4 h-4" />
              </button>
              <button
                onClick={() => handleDelete('designation', designation.id)}
                className="p-2 text-gray-600 hover:text-red-600 hover:bg-red-50 rounded-lg transition-colors"
              >
                <Trash2 className="w-4 h-4" />
              </button>
            </div>
          </div>
        ))}
      </div>
    </div>
  );

  const renderWorkflow = () => (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <h2 className="text-lg font-semibold text-gray-900">Workflow Statuses</h2>
        <button
          onClick={() => handleAdd('status')}
          className="flex items-center space-x-2 bg-blue-600 text-white px-4 py-2 rounded-lg hover:bg-blue-700 transition-colors"
        >
          <Plus className="w-4 h-4" />
          <span>Add Status</span>
        </button>
      </div>

      <div className="bg-white rounded-xl shadow-sm p-6">
        <div className="space-y-4">
          {workflowStatuses.map((status, index) => (
            <div key={status.id} className="flex items-center space-x-4 p-4 border border-gray-200 rounded-lg">
              <div className="flex items-center justify-center w-8 h-8 bg-blue-100 text-blue-800 rounded-full text-sm font-medium">
                {status.order}
              </div>
              <div className="flex-1">
                <h3 className="text-lg font-medium text-gray-900">{status.name}</h3>
                <p className="text-sm text-gray-600">{status.description}</p>
              </div>
              <div className="flex space-x-2">
                <button
                  onClick={() => handleEdit('status', status.id)}
                  className="p-2 text-gray-600 hover:text-blue-600 hover:bg-blue-50 rounded-lg transition-colors"
                >
                  <Edit className="w-4 h-4" />
                </button>
                <button
                  onClick={() => handleDelete('status', status.id)}
                  className="p-2 text-gray-600 hover:text-red-600 hover:bg-red-50 rounded-lg transition-colors"
                >
                  <Trash2 className="w-4 h-4" />
                </button>
              </div>
              {index < workflowStatuses.length - 1 && (
                <div className="absolute left-8 mt-12 w-0.5 h-8 bg-gray-300"></div>
              )}
            </div>
          ))}
        </div>
      </div>
    </div>
  );

  const tabs = [
    { id: 'offices', name: 'Offices & Branches', icon: Building2 },
    { id: 'officers', name: 'Officers & Staff', icon: Users },
    { id: 'designations', name: 'Designations & Roles', icon: Shield },
    { id: 'workflow', name: 'Workflow Statuses', icon: Settings },
  ];

  return (
    <div className="space-y-6">
      {/* Header */}
      <div>
        <h1 className="text-2xl font-bold text-gray-900">Administration</h1>
        <p className="text-gray-600">Manage system configuration and organizational structure</p>
      </div>

      {/* Tabs */}
      <div className="border-b border-gray-200">
        <nav className="-mb-px flex space-x-8">
          {tabs.map((tab) => (
            <button
              key={tab.id}
              onClick={() => setActiveTab(tab.id)}
              className={`flex items-center space-x-2 py-2 px-1 border-b-2 font-medium text-sm ${
                activeTab === tab.id
                  ? 'border-blue-500 text-blue-600'
                  : 'border-transparent text-gray-500 hover:text-gray-700 hover:border-gray-300'
              }`}
            >
              <tab.icon className="w-4 h-4" />
              <span>{tab.name}</span>
            </button>
          ))}
        </nav>
      </div>

      {/* Tab Content */}
      <div>
        {activeTab === 'offices' && renderOffices()}
        {activeTab === 'officers' && renderOfficers()}
        {activeTab === 'designations' && renderDesignations()}
        {activeTab === 'workflow' && renderWorkflow()}
      </div>

      {/* Add Form Modal */}
      {showAddForm && (
        <div className="fixed inset-0 bg-gray-600 bg-opacity-50 flex items-center justify-center z-50">
          <div className="bg-white rounded-xl shadow-xl max-w-md w-full mx-4">
            <div className="p-6 border-b border-gray-200">
              <h2 className="text-xl font-semibold text-gray-900">
                Add New {formType.charAt(0).toUpperCase() + formType.slice(1)}
              </h2>
            </div>
            
            <div className="p-6">
              <p className="text-gray-600 mb-4">
                Form for adding new {formType} would be implemented here.
              </p>
            </div>
            
            <div className="p-6 border-t border-gray-200 flex justify-end space-x-4">
              <button
                onClick={() => setShowAddForm(false)}
                className="px-4 py-2 text-gray-600 hover:text-gray-800 transition-colors"
              >
                Cancel
              </button>
              <button
                onClick={() => {
                  alert(`${formType} added successfully!`);
                  setShowAddForm(false);
                }}
                className="bg-blue-600 text-white px-6 py-2 rounded-lg hover:bg-blue-700 transition-colors"
              >
                Add {formType.charAt(0).toUpperCase() + formType.slice(1)}
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default Administration;