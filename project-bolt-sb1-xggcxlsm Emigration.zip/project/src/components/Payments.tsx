import React, { useState } from 'react';
import { CreditCard, DollarSign, Download, Eye, RefreshCw, CheckCircle, Clock, XCircle, Plus } from 'lucide-react';
import { useAuth } from '../contexts/AuthContext';

const Payments = () => {
  const { user } = useAuth();
  const [showPaymentForm, setShowPaymentForm] = useState(false);
  const [selectedApplication, setSelectedApplication] = useState('');
  const [paymentMethod, setPaymentMethod] = useState('card');

  const payments = [
    {
      id: 'PAY-2025-001234',
      applicationRef: 'APP-2025-001234',
      applicant: 'Kamal Perera',
      service: 'New Passport',
      amount: 3500,
      currency: 'LKR',
      status: 'completed',
      method: 'Credit Card',
      date: '2025-01-10',
      receiptUrl: '#',
    },
    {
      id: 'PAY-2025-001235',
      applicationRef: 'APP-2025-001235',
      applicant: 'Sita Fernando',
      service: 'Passport Renewal',
      amount: 2500,
      currency: 'LKR',
      status: 'completed',
      method: 'Bank Transfer',
      date: '2025-01-10',
      receiptUrl: '#',
    },
    {
      id: 'PAY-2025-001236',
      applicationRef: 'APP-2025-001236',
      applicant: 'Ravi Silva',
      service: 'Express Passport',
      amount: 7500,
      currency: 'LKR',
      status: 'pending',
      method: 'Mobile Payment',
      date: '2025-01-09',
      receiptUrl: null,
    },
    {
      id: 'PAY-2025-001237',
      applicationRef: 'APP-2025-001237',
      applicant: 'Nimal Jayasinghe',
      service: 'Lost Passport',
      amount: 4000,
      currency: 'LKR',
      status: 'failed',
      method: 'Credit Card',
      date: '2025-01-09',
      receiptUrl: null,
    },
  ];

  const feeStructure = [
    { service: 'New Passport (Normal)', fee: 3500, processing: '7-10 days' },
    { service: 'New Passport (Express)', fee: 7500, processing: '2-3 days' },
    { service: 'Passport Renewal (Normal)', fee: 2500, processing: '5-7 days' },
    { service: 'Passport Renewal (Express)', fee: 5500, processing: '1-2 days' },
    { service: 'Lost/Damaged Passport', fee: 4000, processing: '10-14 days' },
    { service: 'Official Passport', fee: 5000, processing: '7-10 days' },
  ];

  const pendingApplications = [
    { ref: 'APP-2025-001240', applicant: 'Chamari Silva', service: 'New Passport', amount: 3500 },
    { ref: 'APP-2025-001241', applicant: 'Sunil Perera', service: 'Passport Renewal', amount: 2500 },
    { ref: 'APP-2025-001242', applicant: 'Priya Fernando', service: 'Express Passport', amount: 7500 },
  ];

  const handlePayment = () => {
    if (!selectedApplication || !paymentMethod) {
      alert('Please select an application and payment method');
      return;
    }

    const application = pendingApplications.find(app => app.ref === selectedApplication);
    if (!application) return;

    // Simulate payment processing
    alert(`Payment initiated for ${application.service}\nAmount: LKR ${application.amount}\nMethod: ${paymentMethod}\nPayment ID: PAY-${Date.now()}`);
    setShowPaymentForm(false);
    setSelectedApplication('');
    setPaymentMethod('card');
  };

  const downloadReceipt = (paymentId: string) => {
    alert(`Downloading receipt for payment ${paymentId}`);
  };

  const processRefund = (paymentId: string) => {
    if (confirm('Are you sure you want to process a refund for this payment?')) {
      alert(`Refund initiated for payment ${paymentId}`);
    }
  };

  const retryPayment = (paymentId: string) => {
    alert(`Retrying payment ${paymentId}`);
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex justify-between items-center">
        <div>
          <h1 className="text-2xl font-bold text-gray-900">Payments</h1>
          <p className="text-gray-600">Manage payments and fee transactions</p>
        </div>
        {user?.role === 'applicant' && (
          <button
            onClick={() => setShowPaymentForm(true)}
            className="flex items-center space-x-2 bg-blue-600 text-white px-4 py-2 rounded-lg hover:bg-blue-700 transition-colors"
          >
            <Plus className="w-4 h-4" />
            <span>Make Payment</span>
          </button>
        )}
      </div>

      {/* Payment Form Modal */}
      {showPaymentForm && (
        <div className="fixed inset-0 bg-gray-600 bg-opacity-50 flex items-center justify-center z-50">
          <div className="bg-white rounded-xl shadow-xl max-w-md w-full mx-4">
            <div className="p-6 border-b border-gray-200">
              <h2 className="text-xl font-semibold text-gray-900">Make Payment</h2>
            </div>
            
            <div className="p-6 space-y-6">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">Select Application *</label>
                <select
                  value={selectedApplication}
                  onChange={(e) => setSelectedApplication(e.target.value)}
                  className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                  required
                >
                  <option value="">Choose application</option>
                  {pendingApplications.map(app => (
                    <option key={app.ref} value={app.ref}>
                      {app.ref} - {app.service} (LKR {app.amount})
                    </option>
                  ))}
                </select>
              </div>
              
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">Payment Method *</label>
                <div className="space-y-3">
                  <label className="flex items-center space-x-3">
                    <input
                      type="radio"
                      value="card"
                      checked={paymentMethod === 'card'}
                      onChange={(e) => setPaymentMethod(e.target.value)}
                      className="text-blue-600"
                    />
                    <CreditCard className="w-5 h-5 text-gray-400" />
                    <span>Credit/Debit Card</span>
                  </label>
                  <label className="flex items-center space-x-3">
                    <input
                      type="radio"
                      value="bank"
                      checked={paymentMethod === 'bank'}
                      onChange={(e) => setPaymentMethod(e.target.value)}
                      className="text-blue-600"
                    />
                    <DollarSign className="w-5 h-5 text-gray-400" />
                    <span>Bank Transfer</span>
                  </label>
                  <label className="flex items-center space-x-3">
                    <input
                      type="radio"
                      value="mobile"
                      checked={paymentMethod === 'mobile'}
                      onChange={(e) => setPaymentMethod(e.target.value)}
                      className="text-blue-600"
                    />
                    <span className="w-5 h-5 bg-purple-500 rounded text-white text-xs flex items-center justify-center">M</span>
                    <span>Mobile Payment</span>
                  </label>
                </div>
              </div>

              {selectedApplication && (
                <div className="bg-blue-50 border border-blue-200 rounded-lg p-4">
                  <h4 className="font-medium text-blue-900 mb-2">Payment Summary</h4>
                  {(() => {
                    const app = pendingApplications.find(a => a.ref === selectedApplication);
                    return app ? (
                      <div className="space-y-1 text-sm text-blue-800">
                        <p>Service: {app.service}</p>
                        <p>Amount: LKR {app.amount}</p>
                        <p>Processing Fee: LKR 50</p>
                        <hr className="border-blue-200 my-2" />
                        <p className="font-medium">Total: LKR {app.amount + 50}</p>
                      </div>
                    ) : null;
                  })()}
                </div>
              )}
            </div>
            
            <div className="p-6 border-t border-gray-200 flex justify-end space-x-4">
              <button
                onClick={() => setShowPaymentForm(false)}
                className="px-4 py-2 text-gray-600 hover:text-gray-800 transition-colors"
              >
                Cancel
              </button>
              <button
                onClick={handlePayment}
                className="bg-blue-600 text-white px-6 py-2 rounded-lg hover:bg-blue-700 transition-colors"
              >
                Proceed to Payment
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Fee Structure */}
      <div className="bg-white rounded-xl shadow-sm">
        <div className="p-6 border-b border-gray-200">
          <h2 className="text-lg font-semibold text-gray-900">Fee Structure</h2>
        </div>
        <div className="p-6">
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            {feeStructure.map((item, index) => (
              <div key={index} className="border border-gray-200 rounded-lg p-4 hover:border-blue-300 transition-colors">
                <h3 className="font-medium text-gray-900 mb-2">{item.service}</h3>
                <div className="flex justify-between items-center mb-2">
                  <span className="text-2xl font-bold text-blue-600">LKR {item.fee}</span>
                </div>
                <p className="text-sm text-gray-600">Processing: {item.processing}</p>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* Payment History */}
      <div className="bg-white rounded-xl shadow-sm">
        <div className="p-6 border-b border-gray-200">
          <h2 className="text-lg font-semibold text-gray-900">Payment History</h2>
        </div>
        
        <div className="overflow-x-auto">
          <table className="w-full">
            <thead className="bg-gray-50">
              <tr>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Payment ID</th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Application</th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Service</th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Amount</th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Method</th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Status</th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Date</th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Actions</th>
              </tr>
            </thead>
            <tbody className="bg-white divide-y divide-gray-200">
              {payments.map((payment) => (
                <tr key={payment.id} className="hover:bg-gray-50">
                  <td className="px-6 py-4 whitespace-nowrap text-sm font-medium text-gray-900">
                    {payment.id}
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-600">
                    <div>
                      <p>{payment.applicationRef}</p>
                      <p className="text-xs text-gray-500">{payment.applicant}</p>
                    </div>
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-600">
                    {payment.service}
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap text-sm font-medium text-gray-900">
                    {payment.currency} {payment.amount}
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-600">
                    {payment.method}
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap">
                    <span className={`inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium ${
                      payment.status === 'completed' 
                        ? 'bg-emerald-100 text-emerald-800'
                        : payment.status === 'pending'
                        ? 'bg-amber-100 text-amber-800'
                        : 'bg-red-100 text-red-800'
                    }`}>
                      {payment.status === 'completed' && <CheckCircle className="w-3 h-3 mr-1" />}
                      {payment.status === 'pending' && <Clock className="w-3 h-3 mr-1" />}
                      {payment.status === 'failed' && <XCircle className="w-3 h-3 mr-1" />}
                      {payment.status.charAt(0).toUpperCase() + payment.status.slice(1)}
                    </span>
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-600">
                    {payment.date}
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-600">
                    <div className="flex space-x-2">
                      {payment.receiptUrl && (
                        <button
                          onClick={() => downloadReceipt(payment.id)}
                          className="text-blue-600 hover:text-blue-800 transition-colors"
                          title="Download Receipt"
                        >
                          <Download className="w-4 h-4" />
                        </button>
                      )}
                      <button
                        className="text-gray-600 hover:text-gray-800 transition-colors"
                        title="View Details"
                      >
                        <Eye className="w-4 h-4" />
                      </button>
                      {payment.status === 'failed' && (
                        <button
                          onClick={() => retryPayment(payment.id)}
                          className="text-amber-600 hover:text-amber-800 transition-colors"
                          title="Retry Payment"
                        >
                          <RefreshCw className="w-4 h-4" />
                        </button>
                      )}
                      {(user?.role === 'admin' || user?.role === 'officer') && payment.status === 'completed' && (
                        <button
                          onClick={() => processRefund(payment.id)}
                          className="text-red-600 hover:text-red-800 transition-colors"
                          title="Process Refund"
                        >
                          <RefreshCw className="w-4 h-4" />
                        </button>
                      )}
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};

export default Payments;