import React, { useState } from 'react';
import { 
  Shield, 
  User, 
  FileText, 
  Settings, 
  Search, 
  Filter, 
  Calendar,
  Eye,
  Download,
  AlertTriangle
} from 'lucide-react';

const AuditLogs = () => {
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedAction, setSelectedAction] = useState('all');
  const [selectedUser, setSelectedUser] = useState('all');
  const [dateRange, setDateRange] = useState({ start: '2025-01-01', end: '2025-01-31' });

  const auditLogs = [
    {
      id: 1,
      timestamp: '2025-01-10 14:30:25',
      user: 'Priya Wickramasinghe',
      userRole: 'Senior Officer',
      action: 'Document Verified',
      resource: 'APP-2025-001234',
      details: 'Verified NIC copy for Kamal Perera',
      ipAddress: '192.168.1.45',
      userAgent: 'Mozilla/5.0 (Windows NT 10.0; Win64; x64)',
      severity: 'info',
    },
    {
      id: 2,
      timestamp: '2025-01-10 14:25:12',
      user: 'admin@immigration.gov.lk',
      userRole: 'System Admin',
      action: 'User Login',
      resource: 'Authentication System',
      details: 'Successful login from Colombo office',
      ipAddress: '192.168.1.10',
      userAgent: 'Mozilla/5.0 (Windows NT 10.0; Win64; x64)',
      severity: 'info',
    },
    {
      id: 3,
      timestamp: '2025-01-10 14:20:08',
      user: 'Sunil Rathnayake',
      userRole: 'Officer',
      action: 'Application Approved',
      resource: 'APP-2025-001235',
      details: 'Approved passport renewal for Sita Fernando',
      ipAddress: '192.168.2.23',
      userAgent: 'Mozilla/5.0 (Windows NT 10.0; Win64; x64)',
      severity: 'info',
    },
    {
      id: 4,
      timestamp: '2025-01-10 14:15:33',
      user: 'system',
      userRole: 'System',
      action: 'Payment Processed',
      resource: 'PAY-2025-001236',
      details: 'Payment of LKR 3,500 processed for APP-2025-001236',
      ipAddress: '10.0.0.1',
      userAgent: 'System Process',
      severity: 'info',
    },
    {
      id: 5,
      timestamp: '2025-01-10 14:10:45',
      user: 'Chamari Silva',
      userRole: 'Officer',
      action: 'Document Rejected',
      resource: 'APP-2025-001237',
      details: 'Rejected passport photo - poor quality',
      ipAddress: '192.168.3.15',
      userAgent: 'Mozilla/5.0 (Windows NT 10.0; Win64; x64)',
      severity: 'warning',
    },
    {
      id: 6,
      timestamp: '2025-01-10 14:05:22',
      user: 'unknown',
      userRole: 'Unknown',
      action: 'Failed Login Attempt',
      resource: 'Authentication System',
      details: 'Multiple failed login attempts for admin account',
      ipAddress: '203.94.123.45',
      userAgent: 'Mozilla/5.0 (Linux; Android 10)',
      severity: 'critical',
    },
    {
      id: 7,
      timestamp: '2025-01-10 14:00:15',
      user: 'admin@immigration.gov.lk',
      userRole: 'System Admin',
      action: 'Settings Modified',
      resource: 'System Configuration',
      details: 'Updated fee structure for express passports',
      ipAddress: '192.168.1.10',
      userAgent: 'Mozilla/5.0 (Windows NT 10.0; Win64; x64)',
      severity: 'warning',
    },
    {
      id: 8,
      timestamp: '2025-01-10 13:55:30',
      user: 'Nimal Fernando',
      userRole: 'Applicant',
      action: 'Application Submitted',
      resource: 'APP-2025-001238',
      details: 'New passport application submitted',
      ipAddress: '112.134.156.78',
      userAgent: 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7)',
      severity: 'info',
    },
  ];

  const actionTypes = [
    { id: 'all', name: 'All Actions' },
    { id: 'login', name: 'User Login' },
    { id: 'logout', name: 'User Logout' },
    { id: 'document', name: 'Document Actions' },
    { id: 'application', name: 'Application Actions' },
    { id: 'payment', name: 'Payment Actions' },
    { id: 'settings', name: 'Settings Changes' },
    { id: 'failed', name: 'Failed Attempts' },
  ];

  const users = [
    { id: 'all', name: 'All Users' },
    { id: 'priya', name: 'Priya Wickramasinghe' },
    { id: 'sunil', name: 'Sunil Rathnayake' },
    { id: 'chamari', name: 'Chamari Silva' },
    { id: 'admin', name: 'System Admin' },
    { id: 'system', name: 'System' },
  ];

  const filteredLogs = auditLogs.filter(log => {
    const matchesSearch = log.details.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         log.user.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         log.resource.toLowerCase().includes(searchTerm.toLowerCase());
    
    const matchesAction = selectedAction === 'all' || 
                         log.action.toLowerCase().includes(selectedAction.toLowerCase());
    
    const matchesUser = selectedUser === 'all' || 
                       log.user.toLowerCase().includes(selectedUser.toLowerCase());
    
    return matchesSearch && matchesAction && matchesUser;
  });

  const getSeverityIcon = (severity: string) => {
    switch (severity) {
      case 'critical':
        return <AlertTriangle className="w-5 h-5 text-red-600" />;
      case 'warning':
        return <AlertTriangle className="w-5 h-5 text-amber-600" />;
      case 'info':
        return <Shield className="w-5 h-5 text-blue-600" />;
      default:
        return <Shield className="w-5 h-5 text-gray-400" />;
    }
  };

  const getSeverityColor = (severity: string) => {
    switch (severity) {
      case 'critical':
        return 'bg-red-100 text-red-800 border-red-200';
      case 'warning':
        return 'bg-amber-100 text-amber-800 border-amber-200';
      case 'info':
        return 'bg-blue-100 text-blue-800 border-blue-200';
      default:
        return 'bg-gray-100 text-gray-800 border-gray-200';
    }
  };

  const exportLogs = (format: string) => {
    alert(`Exporting audit logs in ${format.toUpperCase()} format...`);
  };

  const viewLogDetails = (logId: number) => {
    const log = auditLogs.find(l => l.id === logId);
    if (log) {
      alert(`Log Details:\n\nTimestamp: ${log.timestamp}\nUser: ${log.user}\nAction: ${log.action}\nResource: ${log.resource}\nDetails: ${log.details}\nIP Address: ${log.ipAddress}\nUser Agent: ${log.userAgent}`);
    }
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex justify-between items-center">
        <div>
          <h1 className="text-2xl font-bold text-gray-900">Audit Logs</h1>
          <p className="text-gray-600">Track system activities and user actions for security and compliance</p>
        </div>
        
        <div className="flex space-x-4">
          <button
            onClick={() => exportLogs('csv')}
            className="flex items-center space-x-2 bg-emerald-600 text-white px-4 py-2 rounded-lg hover:bg-emerald-700 transition-colors"
          >
            <Download className="w-4 h-4" />
            <span>Export CSV</span>
          </button>
          <button
            onClick={() => exportLogs('pdf')}
            className="flex items-center space-x-2 bg-red-600 text-white px-4 py-2 rounded-lg hover:bg-red-700 transition-colors"
          >
            <Download className="w-4 h-4" />
            <span>Export PDF</span>
          </button>
        </div>
      </div>

      {/* Filters */}
      <div className="bg-white rounded-xl shadow-sm p-6">
        <div className="grid grid-cols-1 md:grid-cols-5 gap-4">
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">Search</label>
            <div className="relative">
              <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-4 h-4" />
              <input
                type="text"
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="w-full pl-10 pr-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                placeholder="Search logs..."
              />
            </div>
          </div>
          
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">Action Type</label>
            <select
              value={selectedAction}
              onChange={(e) => setSelectedAction(e.target.value)}
              className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
            >
              {actionTypes.map(action => (
                <option key={action.id} value={action.id}>{action.name}</option>
              ))}
            </select>
          </div>
          
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">User</label>
            <select
              value={selectedUser}
              onChange={(e) => setSelectedUser(e.target.value)}
              className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
            >
              {users.map(user => (
                <option key={user.id} value={user.id}>{user.name}</option>
              ))}
            </select>
          </div>
          
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">Start Date</label>
            <input
              type="date"
              value={dateRange.start}
              onChange={(e) => setDateRange(prev => ({ ...prev, start: e.target.value }))}
              className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
            />
          </div>
          
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">End Date</label>
            <input
              type="date"
              value={dateRange.end}
              onChange={(e) => setDateRange(prev => ({ ...prev, end: e.target.value }))}
              className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
            />
          </div>
        </div>
      </div>

      {/* Statistics */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
        <div className="bg-white rounded-xl shadow-sm p-6">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm font-medium text-gray-600">Total Logs</p>
              <p className="text-2xl font-bold text-gray-900">{auditLogs.length}</p>
            </div>
            <FileText className="w-8 h-8 text-blue-500" />
          </div>
        </div>
        
        <div className="bg-white rounded-xl shadow-sm p-6">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm font-medium text-gray-600">Critical Events</p>
              <p className="text-2xl font-bold text-red-600">
                {auditLogs.filter(log => log.severity === 'critical').length}
              </p>
            </div>
            <AlertTriangle className="w-8 h-8 text-red-500" />
          </div>
        </div>
        
        <div className="bg-white rounded-xl shadow-sm p-6">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm font-medium text-gray-600">Warning Events</p>
              <p className="text-2xl font-bold text-amber-600">
                {auditLogs.filter(log => log.severity === 'warning').length}
              </p>
            </div>
            <AlertTriangle className="w-8 h-8 text-amber-500" />
          </div>
        </div>
        
        <div className="bg-white rounded-xl shadow-sm p-6">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm font-medium text-gray-600">Active Users</p>
              <p className="text-2xl font-bold text-emerald-600">
                {new Set(auditLogs.map(log => log.user)).size}
              </p>
            </div>
            <User className="w-8 h-8 text-emerald-500" />
          </div>
        </div>
      </div>

      {/* Audit Logs Table */}
      <div className="bg-white rounded-xl shadow-sm">
        <div className="p-6 border-b border-gray-200">
          <h2 className="text-lg font-semibold text-gray-900">
            Audit Trail ({filteredLogs.length} entries)
          </h2>
        </div>
        
        <div className="overflow-x-auto">
          <table className="w-full">
            <thead className="bg-gray-50">
              <tr>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  Timestamp
                </th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  User
                </th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  Action
                </th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  Resource
                </th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  Details
                </th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  IP Address
                </th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  Severity
                </th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  Actions
                </th>
              </tr>
            </thead>
            <tbody className="bg-white divide-y divide-gray-200">
              {filteredLogs.map((log) => (
                <tr key={log.id} className="hover:bg-gray-50">
                  <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-900">
                    {log.timestamp}
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap">
                    <div>
                      <div className="text-sm font-medium text-gray-900">{log.user}</div>
                      <div className="text-sm text-gray-500">{log.userRole}</div>
                    </div>
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-900">
                    {log.action}
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-600">
                    {log.resource}
                  </td>
                  <td className="px-6 py-4 text-sm text-gray-600 max-w-xs truncate">
                    {log.details}
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-600">
                    {log.ipAddress}
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap">
                    <div className={`inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium border ${getSeverityColor(log.severity)}`}>
                      {getSeverityIcon(log.severity)}
                      <span className="ml-1 capitalize">{log.severity}</span>
                    </div>
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                    <button
                      onClick={() => viewLogDetails(log.id)}
                      className="text-blue-600 hover:text-blue-800 transition-colors"
                      title="View Details"
                    >
                      <Eye className="w-4 h-4" />
                    </button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
        
        {filteredLogs.length === 0 && (
          <div className="p-12 text-center">
            <Shield className="w-12 h-12 text-gray-400 mx-auto mb-4" />
            <p className="text-gray-500">No audit logs found matching your criteria.</p>
          </div>
        )}
      </div>
    </div>
  );
};

export default AuditLogs;