import React from 'react';
import { 
  FileText, 
  Calendar, 
  CheckCircle, 
  XCircle, 
  Clock, 
  DollarSign, 
  Users, 
  AlertTriangle,
  TrendingUp,
  Activity,
  Plus,
  Search
} from 'lucide-react';
import { useAuth } from '../contexts/AuthContext';

const Dashboard = () => {
  const { user } = useAuth();

  const stats = [
    {
      name: 'Total Applications',
      value: '2,847',
      change: '+12%',
      changeType: 'increase',
      icon: FileText,
      color: 'bg-blue-500',
    },
    {
      name: 'Pending Applications',
      value: '342',
      change: '-8%',
      changeType: 'decrease',
      icon: Clock,
      color: 'bg-amber-500',
    },
    {
      name: 'Approved Today',
      value: '89',
      change: '+23%',
      changeType: 'increase',
      icon: CheckCircle,
      color: 'bg-emerald-500',
    },
    {
      name: 'Revenue This Month',
      value: 'LKR 2.4M',
      change: '+15%',
      changeType: 'increase',
      icon: DollarSign,
      color: 'bg-purple-500',
    },
  ];

  const recentApplications = [
    {
      id: 'APP-2025-001234',
      applicant: 'Kamal Perera',
      type: 'New Passport',
      status: 'Under Review',
      date: '2025-01-10',
      statusColor: 'bg-amber-100 text-amber-800',
    },
    {
      id: 'APP-2025-001235',
      applicant: 'Sita Fernando',
      type: 'Passport Renewal',
      status: 'Approved',
      date: '2025-01-10',
      statusColor: 'bg-emerald-100 text-emerald-800',
    },
    {
      id: 'APP-2025-001236',
      applicant: 'Ravi Silva',
      type: 'Lost Passport',
      status: 'Documents Required',
      date: '2025-01-09',
      statusColor: 'bg-red-100 text-red-800',
    },
    {
      id: 'APP-2025-001237',
      applicant: 'Nimal Jayasinghe',
      type: 'Express Passport',
      status: 'Processing',
      date: '2025-01-09',
      statusColor: 'bg-blue-100 text-blue-800',
    },
  ];

  const upcomingAppointments = [
    {
      time: '09:00 AM',
      applicant: 'Priya Wickramasinghe',
      purpose: 'Document Verification',
      branch: 'Colombo Main',
    },
    {
      time: '10:30 AM',
      applicant: 'Sunil Rathnayake',
      purpose: 'Passport Collection',
      branch: 'Colombo Main',
    },
    {
      time: '02:00 PM',
      applicant: 'Chamari Dissanayake',
      purpose: 'New Application',
      branch: 'Kandy Branch',
    },
  ];

  const notifications = [
    {
      type: 'info',
      title: 'System Maintenance',
      message: 'Scheduled maintenance on Jan 15, 2025 from 2:00 AM - 4:00 AM',
      time: '2 hours ago',
    },
    {
      type: 'warning',
      title: 'Document Verification Backlog',
      message: '45 applications pending document verification',
      time: '4 hours ago',
    },
    {
      type: 'success',
      title: 'New Integration Active',
      message: 'Police verification system integration is now live',
      time: '1 day ago',
    },
  ];

  return (
    <div className="space-y-6">
      {/* Welcome Section */}
      <div className="bg-gradient-to-r from-blue-600 to-emerald-600 rounded-xl p-6 text-white">
        <h1 className="text-2xl font-bold mb-2">
          Welcome back, {user?.name}!
        </h1>
        <p className="opacity-90">
          {user?.role === 'admin' && 'Manage the immigration system and oversee all operations.'}
          {user?.role === 'officer' && 'Review applications and assist applicants with their requests.'}
          {user?.role === 'applicant' && 'Track your applications and manage your immigration documents.'}
        </p>
      </div>

      {/* Stats Grid */}
      {(user?.role === 'officer' || user?.role === 'admin') && (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
          {stats.map((stat) => (
            <div key={stat.name} className="bg-white rounded-xl shadow-sm p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm font-medium text-gray-600">{stat.name}</p>
                  <p className="text-2xl font-bold text-gray-900">{stat.value}</p>
                </div>
                <div className={`${stat.color} p-3 rounded-lg`}>
                  <stat.icon className="w-6 h-6 text-white" />
                </div>
              </div>
              <div className="mt-4 flex items-center">
                <span className={`text-sm font-medium ${
                  stat.changeType === 'increase' ? 'text-emerald-600' : 'text-red-600'
                }`}>
                  {stat.change}
                </span>
                <span className="text-sm text-gray-500 ml-2">from last month</span>
              </div>
            </div>
          ))}
        </div>
      )}

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Quick Actions */}
        <div className="bg-white rounded-xl shadow-sm p-6">
          <h3 className="text-lg font-semibold text-gray-900 mb-4">Quick Actions</h3>
          <div className="grid grid-cols-2 gap-4">
            <button className="flex items-center justify-center p-4 bg-blue-50 hover:bg-blue-100 rounded-lg transition-colors group">
              <div className="text-center">
                <Plus className="w-8 h-8 text-blue-600 mx-auto mb-2 group-hover:scale-110 transition-transform" />
                <span className="text-sm font-medium text-blue-900">New Application</span>
              </div>
            </button>
            <button className="flex items-center justify-center p-4 bg-emerald-50 hover:bg-emerald-100 rounded-lg transition-colors group">
              <div className="text-center">
                <Calendar className="w-8 h-8 text-emerald-600 mx-auto mb-2 group-hover:scale-110 transition-transform" />
                <span className="text-sm font-medium text-emerald-900">Book Appointment</span>
              </div>
            </button>
            <button className="flex items-center justify-center p-4 bg-purple-50 hover:bg-purple-100 rounded-lg transition-colors group">
              <div className="text-center">
                <Search className="w-8 h-8 text-purple-600 mx-auto mb-2 group-hover:scale-110 transition-transform" />
                <span className="text-sm font-medium text-purple-900">Track Status</span>
              </div>
            </button>
            <button className="flex items-center justify-center p-4 bg-amber-50 hover:bg-amber-100 rounded-lg transition-colors group">
              <div className="text-center">
                <DollarSign className="w-8 h-8 text-amber-600 mx-auto mb-2 group-hover:scale-110 transition-transform" />
                <span className="text-sm font-medium text-amber-900">Pay Fees</span>
              </div>
            </button>
          </div>
        </div>

        {/* Notifications */}
        <div className="bg-white rounded-xl shadow-sm p-6">
          <h3 className="text-lg font-semibold text-gray-900 mb-4">Notifications</h3>
          <div className="space-y-4">
            {notifications.map((notification, index) => (
              <div key={index} className="flex items-start space-x-3 p-3 rounded-lg bg-gray-50">
                <div className={`p-1 rounded-full ${
                  notification.type === 'info' ? 'bg-blue-100' :
                  notification.type === 'warning' ? 'bg-amber-100' : 'bg-emerald-100'
                }`}>
                  {notification.type === 'info' && <Activity className="w-4 h-4 text-blue-600" />}
                  {notification.type === 'warning' && <AlertTriangle className="w-4 h-4 text-amber-600" />}
                  {notification.type === 'success' && <CheckCircle className="w-4 h-4 text-emerald-600" />}
                </div>
                <div className="flex-1 min-w-0">
                  <p className="text-sm font-medium text-gray-900">{notification.title}</p>
                  <p className="text-sm text-gray-600">{notification.message}</p>
                  <p className="text-xs text-gray-500 mt-1">{notification.time}</p>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Recent Applications */}
        <div className="bg-white rounded-xl shadow-sm p-6">
          <h3 className="text-lg font-semibold text-gray-900 mb-4">Recent Applications</h3>
          <div className="space-y-4">
            {recentApplications.map((app) => (
              <div key={app.id} className="flex items-center justify-between p-4 border border-gray-200 rounded-lg hover:bg-gray-50 transition-colors">
                <div className="flex-1">
                  <div className="flex items-center justify-between mb-2">
                    <p className="text-sm font-medium text-gray-900">{app.applicant}</p>
                    <span className={`px-2 py-1 text-xs font-medium rounded-full ${app.statusColor}`}>
                      {app.status}
                    </span>
                  </div>
                  <p className="text-sm text-gray-600">{app.type}</p>
                  <p className="text-xs text-gray-500">{app.id} • {app.date}</p>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Upcoming Appointments */}
        <div className="bg-white rounded-xl shadow-sm p-6">
          <h3 className="text-lg font-semibold text-gray-900 mb-4">Today's Appointments</h3>
          <div className="space-y-4">
            {upcomingAppointments.map((appointment, index) => (
              <div key={index} className="flex items-center space-x-4 p-4 border border-gray-200 rounded-lg">
                <div className="bg-blue-100 text-blue-800 px-3 py-1 rounded-lg text-sm font-medium">
                  {appointment.time}
                </div>
                <div className="flex-1">
                  <p className="text-sm font-medium text-gray-900">{appointment.applicant}</p>
                  <p className="text-sm text-gray-600">{appointment.purpose}</p>
                  <p className="text-xs text-gray-500">{appointment.branch}</p>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
};

export default Dashboard;