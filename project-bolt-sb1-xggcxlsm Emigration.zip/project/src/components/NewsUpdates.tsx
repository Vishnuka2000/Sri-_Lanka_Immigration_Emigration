import React from 'react';
import { Calendar, ArrowRight, AlertCircle } from 'lucide-react';

const NewsUpdates = () => {
  const news = [
    {
      type: 'update',
      title: 'New Online Visa Application System Launched',
      description: 'Experience our enhanced digital platform for faster visa processing with improved user interface and security features.',
      date: '2025-01-10',
      urgent: false,
    },
    {
      type: 'alert',
      title: 'Temporary Service Suspension Notice',
      description: 'Passport services will be temporarily unavailable on January 15th due to system maintenance. Emergency services remain active.',
      date: '2025-01-08',
      urgent: true,
    },
    {
      type: 'update',
      title: 'Updated Travel Requirements for EU Countries',
      description: 'New documentation requirements now in effect for travelers to European Union member states. Check requirements before travel.',
      date: '2025-01-05',
      urgent: false,
    },
  ];

  return (
    <section className="py-16 bg-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-12">
          <h2 className="text-3xl font-bold text-gray-900 mb-4">Latest News & Updates</h2>
          <p className="text-xl text-gray-600">Stay informed about important announcements and service updates</p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {news.map((item, index) => (
            <div
              key={index}
              className={`rounded-xl shadow-lg hover:shadow-xl transition-all duration-300 overflow-hidden group cursor-pointer transform hover:scale-105 ${
                item.urgent ? 'border-2 border-red-200 bg-red-50' : 'bg-white'
              }`}
            >
              <div className="p-6">
                <div className="flex items-center justify-between mb-4">
                  <div className="flex items-center space-x-2">
                    <Calendar size={16} className="text-gray-500" />
                    <span className="text-sm text-gray-500">
                      {new Date(item.date).toLocaleDateString('en-US', { 
                        year: 'numeric', 
                        month: 'long', 
                        day: 'numeric' 
                      })}
                    </span>
                  </div>
                  {item.urgent && (
                    <div className="flex items-center space-x-1 bg-red-100 text-red-700 px-2 py-1 rounded-full text-xs font-semibold">
                      <AlertCircle size={12} />
                      <span>Urgent</span>
                    </div>
                  )}
                </div>
                
                <h3 className="text-xl font-semibold text-gray-900 mb-3 group-hover:text-blue-600 transition-colors">
                  {item.title}
                </h3>
                
                <p className="text-gray-600 mb-4 line-clamp-3">{item.description}</p>
                
                <button className="flex items-center space-x-2 text-blue-600 hover:text-blue-700 font-semibold group-hover:translate-x-1 transition-transform">
                  <span>Read More</span>
                  <ArrowRight size={16} />
                </button>
              </div>
            </div>
          ))}
        </div>

        <div className="text-center mt-12">
          <button className="bg-gradient-to-r from-blue-600 to-emerald-600 text-white px-8 py-3 rounded-lg hover:from-blue-700 hover:to-emerald-700 transition-all duration-300 font-semibold">
            View All News
          </button>
        </div>
      </div>
    </section>
  );
};

export default NewsUpdates;