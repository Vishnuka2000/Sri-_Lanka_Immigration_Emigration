import React, { useState } from 'react';
import { 
  BarChart3, 
  TrendingUp, 
  Download, 
  Calendar, 
  Filter,
  FileText,
  Users,
  DollarSign,
  Clock
} from 'lucide-react';

const Reports = () => {
  const [dateRange, setDateRange] = useState({ start: '2025-01-01', end: '2025-01-31' });
  const [selectedBranch, setSelectedBranch] = useState('all');
  const [selectedType, setSelectedType] = useState('all');
  const [activeTab, setActiveTab] = useState('statistics');

  const branches = [
    { id: 'all', name: 'All Branches' },
    { id: 'colombo-main', name: 'Colombo Main Office' },
    { id: 'kandy', name: 'Kandy Branch' },
    { id: 'galle', name: 'Galle Branch' },
    { id: 'jaffna', name: 'Jaffna Branch' },
  ];

  const applicationTypes = [
    { id: 'all', name: 'All Types' },
    { id: 'new', name: 'New Passport' },
    { id: 'renewal', name: 'Passport Renewal' },
    { id: 'lost', name: 'Lost Passport' },
    { id: 'damaged', name: 'Damaged Passport' },
  ];

  const statisticsData = {
    totalApplications: 2847,
    approvedApplications: 2456,
    rejectedApplications: 234,
    pendingApplications: 157,
    totalRevenue: 8542000,
    averageProcessingTime: 7.2,
    applicationsByType: [
      { type: 'New Passport', count: 1245, percentage: 43.7 },
      { type: 'Renewal', count: 987, percentage: 34.7 },
      { type: 'Lost Passport', count: 345, percentage: 12.1 },
      { type: 'Damaged Passport', count: 270, percentage: 9.5 },
    ],
    monthlyTrends: [
      { month: 'Jan', applications: 245, approvals: 220, revenue: 735000 },
      { month: 'Feb', applications: 289, approvals: 267, revenue: 867000 },
      { month: 'Mar', applications: 312, approvals: 298, revenue: 945000 },
      { month: 'Apr', applications: 298, approvals: 285, revenue: 912000 },
      { month: 'May', applications: 334, approvals: 318, revenue: 1023000 },
      { month: 'Jun', applications: 356, approvals: 342, revenue: 1087000 },
    ],
  };

  const detailedReports = [
    {
      ref: 'APP-2025-001234',
      applicant: 'Kamal Perera',
      type: 'New Passport',
      submitDate: '2025-01-10',
      status: 'Approved',
      branch: 'Colombo Main',
      officer: 'Priya Wickramasinghe',
      amount: 3500,
      processingDays: 5,
    },
    {
      ref: 'APP-2025-001235',
      applicant: 'Sita Fernando',
      type: 'Passport Renewal',
      submitDate: '2025-01-09',
      status: 'Completed',
      branch: 'Kandy Branch',
      officer: 'Sunil Rathnayake',
      amount: 2500,
      processingDays: 6,
    },
    {
      ref: 'APP-2025-001236',
      applicant: 'Ravi Silva',
      type: 'Lost Passport',
      submitDate: '2025-01-08',
      status: 'Under Review',
      branch: 'Galle Branch',
      officer: 'Chamari Silva',
      amount: 4000,
      processingDays: 3,
    },
    {
      ref: 'APP-2025-001237',
      applicant: 'Nimal Jayasinghe',
      type: 'Express Passport',
      submitDate: '2025-01-07',
      status: 'Approved',
      branch: 'Colombo Main',
      officer: 'Priya Wickramasinghe',
      amount: 7500,
      processingDays: 2,
    },
  ];

  const exportReport = (format: string) => {
    alert(`Exporting report in ${format.toUpperCase()} format...`);
  };

  const renderStatistics = () => (
    <div className="space-y-6">
      {/* Key Metrics */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        <div className="bg-white rounded-xl shadow-sm p-6">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm font-medium text-gray-600">Total Applications</p>
              <p className="text-2xl font-bold text-gray-900">{statisticsData.totalApplications.toLocaleString()}</p>
            </div>
            <FileText className="w-8 h-8 text-blue-500" />
          </div>
          <div className="mt-4 flex items-center">
            <TrendingUp className="w-4 h-4 text-emerald-500 mr-1" />
            <span className="text-sm text-emerald-600">+12% from last month</span>
          </div>
        </div>

        <div className="bg-white rounded-xl shadow-sm p-6">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm font-medium text-gray-600">Approval Rate</p>
              <p className="text-2xl font-bold text-emerald-600">
                {((statisticsData.approvedApplications / statisticsData.totalApplications) * 100).toFixed(1)}%
              </p>
            </div>
            <BarChart3 className="w-8 h-8 text-emerald-500" />
          </div>
          <div className="mt-4">
            <span className="text-sm text-gray-600">
              {statisticsData.approvedApplications.toLocaleString()} approved
            </span>
          </div>
        </div>

        <div className="bg-white rounded-xl shadow-sm p-6">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm font-medium text-gray-600">Total Revenue</p>
              <p className="text-2xl font-bold text-purple-600">
                LKR {(statisticsData.totalRevenue / 1000000).toFixed(1)}M
              </p>
            </div>
            <DollarSign className="w-8 h-8 text-purple-500" />
          </div>
          <div className="mt-4 flex items-center">
            <TrendingUp className="w-4 h-4 text-emerald-500 mr-1" />
            <span className="text-sm text-emerald-600">+15% from last month</span>
          </div>
        </div>

        <div className="bg-white rounded-xl shadow-sm p-6">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm font-medium text-gray-600">Avg Processing Time</p>
              <p className="text-2xl font-bold text-amber-600">{statisticsData.averageProcessingTime} days</p>
            </div>
            <Clock className="w-8 h-8 text-amber-500" />
          </div>
          <div className="mt-4">
            <span className="text-sm text-gray-600">Target: 7 days</span>
          </div>
        </div>
      </div>

      {/* Application Types Chart */}
      <div className="bg-white rounded-xl shadow-sm p-6">
        <h3 className="text-lg font-semibold text-gray-900 mb-6">Applications by Type</h3>
        <div className="space-y-4">
          {statisticsData.applicationsByType.map((item, index) => (
            <div key={index} className="flex items-center justify-between">
              <div className="flex items-center space-x-3">
                <div className={`w-4 h-4 rounded ${
                  index === 0 ? 'bg-blue-500' :
                  index === 1 ? 'bg-emerald-500' :
                  index === 2 ? 'bg-amber-500' : 'bg-purple-500'
                }`}></div>
                <span className="text-sm font-medium text-gray-900">{item.type}</span>
              </div>
              <div className="flex items-center space-x-4">
                <div className="w-32 bg-gray-200 rounded-full h-2">
                  <div 
                    className={`h-2 rounded-full ${
                      index === 0 ? 'bg-blue-500' :
                      index === 1 ? 'bg-emerald-500' :
                      index === 2 ? 'bg-amber-500' : 'bg-purple-500'
                    }`}
                    style={{ width: `${item.percentage}%` }}
                  ></div>
                </div>
                <span className="text-sm text-gray-600 w-16 text-right">
                  {item.count} ({item.percentage}%)
                </span>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Monthly Trends */}
      <div className="bg-white rounded-xl shadow-sm p-6">
        <h3 className="text-lg font-semibold text-gray-900 mb-6">Monthly Trends</h3>
        <div className="overflow-x-auto">
          <table className="w-full">
            <thead>
              <tr className="border-b border-gray-200">
                <th className="text-left py-3 px-4 font-medium text-gray-900">Month</th>
                <th className="text-left py-3 px-4 font-medium text-gray-900">Applications</th>
                <th className="text-left py-3 px-4 font-medium text-gray-900">Approvals</th>
                <th className="text-left py-3 px-4 font-medium text-gray-900">Revenue (LKR)</th>
                <th className="text-left py-3 px-4 font-medium text-gray-900">Approval Rate</th>
              </tr>
            </thead>
            <tbody>
              {statisticsData.monthlyTrends.map((month, index) => (
                <tr key={index} className="border-b border-gray-100 hover:bg-gray-50">
                  <td className="py-3 px-4 text-gray-900">{month.month}</td>
                  <td className="py-3 px-4 text-gray-600">{month.applications}</td>
                  <td className="py-3 px-4 text-emerald-600">{month.approvals}</td>
                  <td className="py-3 px-4 text-purple-600">{month.revenue.toLocaleString()}</td>
                  <td className="py-3 px-4 text-gray-600">
                    {((month.approvals / month.applications) * 100).toFixed(1)}%
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );

  const renderDetailedReport = () => (
    <div className="bg-white rounded-xl shadow-sm">
      <div className="p-6 border-b border-gray-200">
        <h3 className="text-lg font-semibold text-gray-900">Detailed Application Report</h3>
      </div>
      
      <div className="overflow-x-auto">
        <table className="w-full">
          <thead className="bg-gray-50">
            <tr>
              <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                Application Ref
              </th>
              <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                Applicant
              </th>
              <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                Type
              </th>
              <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                Submit Date
              </th>
              <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                Status
              </th>
              <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                Branch
              </th>
              <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                Officer
              </th>
              <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                Amount
              </th>
              <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                Processing Days
              </th>
            </tr>
          </thead>
          <tbody className="bg-white divide-y divide-gray-200">
            {detailedReports.map((report, index) => (
              <tr key={index} className="hover:bg-gray-50">
                <td className="px-6 py-4 whitespace-nowrap text-sm font-medium text-gray-900">
                  {report.ref}
                </td>
                <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-900">
                  {report.applicant}
                </td>
                <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-600">
                  {report.type}
                </td>
                <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-600">
                  {report.submitDate}
                </td>
                <td className="px-6 py-4 whitespace-nowrap">
                  <span className={`px-2 py-1 text-xs font-medium rounded-full ${
                    report.status === 'Completed' || report.status === 'Approved'
                      ? 'bg-emerald-100 text-emerald-800'
                      : report.status === 'Under Review'
                      ? 'bg-amber-100 text-amber-800'
                      : 'bg-red-100 text-red-800'
                  }`}>
                    {report.status}
                  </span>
                </td>
                <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-600">
                  {report.branch}
                </td>
                <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-600">
                  {report.officer}
                </td>
                <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-900">
                  LKR {report.amount.toLocaleString()}
                </td>
                <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-600">
                  {report.processingDays}
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex justify-between items-center">
        <div>
          <h1 className="text-2xl font-bold text-gray-900">Reports & Analytics</h1>
          <p className="text-gray-600">Generate and analyze application reports</p>
        </div>
      </div>

      {/* Filters */}
      <div className="bg-white rounded-xl shadow-sm p-6">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">Start Date</label>
            <input
              type="date"
              value={dateRange.start}
              onChange={(e) => setDateRange(prev => ({ ...prev, start: e.target.value }))}
              className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
            />
          </div>
          
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">End Date</label>
            <input
              type="date"
              value={dateRange.end}
              onChange={(e) => setDateRange(prev => ({ ...prev, end: e.target.value }))}
              className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
            />
          </div>
          
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">Branch</label>
            <select
              value={selectedBranch}
              onChange={(e) => setSelectedBranch(e.target.value)}
              className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
            >
              {branches.map(branch => (
                <option key={branch.id} value={branch.id}>{branch.name}</option>
              ))}
            </select>
          </div>
          
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">Application Type</label>
            <select
              value={selectedType}
              onChange={(e) => setSelectedType(e.target.value)}
              className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
            >
              {applicationTypes.map(type => (
                <option key={type.id} value={type.id}>{type.name}</option>
              ))}
            </select>
          </div>
        </div>
      </div>

      {/* Tabs */}
      <div className="border-b border-gray-200">
        <nav className="-mb-px flex space-x-8">
          <button
            onClick={() => setActiveTab('statistics')}
            className={`py-2 px-1 border-b-2 font-medium text-sm ${
              activeTab === 'statistics'
                ? 'border-blue-500 text-blue-600'
                : 'border-transparent text-gray-500 hover:text-gray-700 hover:border-gray-300'
            }`}
          >
            Statistics
          </button>
          <button
            onClick={() => setActiveTab('detailed')}
            className={`py-2 px-1 border-b-2 font-medium text-sm ${
              activeTab === 'detailed'
                ? 'border-blue-500 text-blue-600'
                : 'border-transparent text-gray-500 hover:text-gray-700 hover:border-gray-300'
            }`}
          >
            Detailed Report
          </button>
        </nav>
      </div>

      {/* Export Buttons */}
      <div className="flex justify-end space-x-4">
        <button
          onClick={() => exportReport('csv')}
          className="flex items-center space-x-2 bg-emerald-600 text-white px-4 py-2 rounded-lg hover:bg-emerald-700 transition-colors"
        >
          <Download className="w-4 h-4" />
          <span>Export CSV</span>
        </button>
        <button
          onClick={() => exportReport('pdf')}
          className="flex items-center space-x-2 bg-red-600 text-white px-4 py-2 rounded-lg hover:bg-red-700 transition-colors"
        >
          <Download className="w-4 h-4" />
          <span>Export PDF</span>
        </button>
        <button
          onClick={() => exportReport('excel')}
          className="flex items-center space-x-2 bg-blue-600 text-white px-4 py-2 rounded-lg hover:bg-blue-700 transition-colors"
        >
          <Download className="w-4 h-4" />
          <span>Export Excel</span>
        </button>
      </div>

      {/* Tab Content */}
      {activeTab === 'statistics' && renderStatistics()}
      {activeTab === 'detailed' && renderDetailedReport()}
    </div>
  );
};

export default Reports;