import React from 'react';
import { MapPin, Phone, Mail, Clock, Facebook, Twitter, Youtube, Instagram } from 'lucide-react';

const Footer = () => {
  return (
    <footer className="bg-gray-900 text-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
          {/* Contact Information */}
          <div>
            <h3 className="text-lg font-semibold mb-6">Contact Information</h3>
            <div className="space-y-4">
              <div className="flex items-start space-x-3">
                <MapPin size={20} className="text-emerald-400 mt-1 flex-shrink-0" />
                <p className="text-gray-300">
                  41, Ananda Rajakaruna Mawatha,<br />
                  Colombo 10, Sri Lanka
                </p>
              </div>
              <div className="flex items-center space-x-3">
                <Phone size={20} className="text-emerald-400" />
                <p className="text-gray-300">+94 11 532 9200</p>
              </div>
              <div className="flex items-center space-x-3">
                <Mail size={20} className="text-emerald-400" />
                <p className="text-gray-300">info@immigration.gov.lk</p>
              </div>
            </div>
          </div>

          {/* Office Hours */}
          <div>
            <h3 className="text-lg font-semibold mb-6">Office Hours</h3>
            <div className="space-y-2">
              <div className="flex items-center space-x-3">
                <Clock size={20} className="text-emerald-400" />
                <div>
                  <p className="text-gray-300">Monday - Friday</p>
                  <p className="text-sm text-gray-400">8:30 AM - 4:30 PM</p>
                </div>
              </div>
              <div className="mt-4">
                <p className="text-gray-300">Saturday - Sunday</p>
                <p className="text-sm text-gray-400">Closed</p>
              </div>
              <div className="mt-4 p-3 bg-blue-900/50 rounded-lg">
                <p className="text-sm text-blue-300">Emergency services available 24/7</p>
              </div>
            </div>
          </div>

          {/* Quick Links */}
          <div>
            <h3 className="text-lg font-semibold mb-6">Quick Links</h3>
            <ul className="space-y-3">
              <li><a href="#" className="text-gray-300 hover:text-emerald-400 transition-colors">Visa Applications</a></li>
              <li><a href="#" className="text-gray-300 hover:text-emerald-400 transition-colors">Passport Services</a></li>
              <li><a href="#" className="text-gray-300 hover:text-emerald-400 transition-colors">Application Status</a></li>
              <li><a href="#" className="text-gray-300 hover:text-emerald-400 transition-colors">Travel Advisory</a></li>
              <li><a href="#" className="text-gray-300 hover:text-emerald-400 transition-colors">Fee Structure</a></li>
              <li><a href="#" className="text-gray-300 hover:text-emerald-400 transition-colors">Document Requirements</a></li>
            </ul>
          </div>

          {/* Government Links */}
          <div>
            <h3 className="text-lg font-semibold mb-6">Government Links</h3>
            <ul className="space-y-3">
              <li><a href="#" className="text-gray-300 hover:text-emerald-400 transition-colors">Ministry of Foreign Affairs</a></li>
              <li><a href="#" className="text-gray-300 hover:text-emerald-400 transition-colors">Ministry of Defense</a></li>
              <li><a href="#" className="text-gray-300 hover:text-emerald-400 transition-colors">Sri Lanka Tourism</a></li>
              <li><a href="#" className="text-gray-300 hover:text-emerald-400 transition-colors">Department of Census</a></li>
              <li><a href="#" className="text-gray-300 hover:text-emerald-400 transition-colors">Government Information</a></li>
            </ul>
          </div>
        </div>

        {/* Social Media and Copyright */}
        <div className="border-t border-gray-700 mt-12 pt-8">
          <div className="flex flex-col md:flex-row justify-between items-center">
            <div className="flex space-x-6 mb-4 md:mb-0">
              <a href="#" className="text-gray-400 hover:text-emerald-400 transition-colors">
                <Facebook size={24} />
              </a>
              <a href="#" className="text-gray-400 hover:text-emerald-400 transition-colors">
                <Twitter size={24} />
              </a>
              <a href="#" className="text-gray-400 hover:text-emerald-400 transition-colors">
                <Youtube size={24} />
              </a>
              <a href="#" className="text-gray-400 hover:text-emerald-400 transition-colors">
                <Instagram size={24} />
              </a>
            </div>
            <div className="text-center md:text-right">
              <p className="text-gray-400 text-sm">
                © 2025 Department of Immigration & Emigration, Sri Lanka. All rights reserved.
              </p>
              <div className="flex space-x-4 mt-2 justify-center md:justify-end">
                <a href="#" className="text-gray-400 hover:text-emerald-400 text-sm transition-colors">Privacy Policy</a>
                <a href="#" className="text-gray-400 hover:text-emerald-400 text-sm transition-colors">Terms of Service</a>
                <a href="#" className="text-gray-400 hover:text-emerald-400 text-sm transition-colors">Accessibility</a>
              </div>
            </div>
          </div>
        </div>
      </div>
    </footer>
  );
};

export default Footer;