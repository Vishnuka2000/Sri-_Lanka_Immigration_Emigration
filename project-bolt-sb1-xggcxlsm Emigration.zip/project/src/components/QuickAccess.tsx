import React from 'react';
import { FileText, Calendar, CreditCard, HelpCircle } from 'lucide-react';

const QuickAccess = () => {
  const quickLinks = [
    {
      icon: FileText,
      title: 'New Application',
      description: 'Start a new visa or passport application',
      color: 'bg-blue-500 hover:bg-blue-600',
    },
    {
      icon: Calendar,
      title: 'Book Appointment',
      description: 'Schedule an appointment at our office',
      color: 'bg-emerald-500 hover:bg-emerald-600',
    },
    {
      icon: CreditCard,
      title: 'Pay Fees',
      description: 'Pay application fees online',
      color: 'bg-amber-500 hover:bg-amber-600',
    },
    {
      icon: HelpCircle,
      title: 'Help & Support',
      description: 'Get assistance with your application',
      color: 'bg-purple-500 hover:bg-purple-600',
    },
  ];

  return (
    <section className="py-16 bg-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <h2 className="text-3xl font-bold text-center text-gray-900 mb-12">Quick Access</h2>
        
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
          {quickLinks.map((link, index) => (
            <button
              key={index}
              className={`${link.color} text-white p-6 rounded-xl transition-all duration-300 transform hover:scale-105 shadow-lg hover:shadow-xl group`}
            >
              <div className="text-center">
                <link.icon size={48} className="mx-auto mb-4 group-hover:scale-110 transition-transform" />
                <h3 className="text-lg font-semibold mb-2">{link.title}</h3>
                <p className="text-sm opacity-90">{link.description}</p>
              </div>
            </button>
          ))}
        </div>
      </div>
    </section>
  );
};

export default QuickAccess;