import React, { useState } from 'react';
import { Calendar, Clock, MapPin, User, Phone, Mail, Plus, CreditCard as Edit, Trash2, CheckCircle, XCircle } from 'lucide-react';
import { useAuth } from '../contexts/AuthContext';

const Appointments = () => {
  const { user } = useAuth();
  const [showBookingForm, setShowBookingForm] = useState(false);
  const [selectedDate, setSelectedDate] = useState('');
  const [selectedTime, setSelectedTime] = useState('');
  const [selectedBranch, setBranch] = useState('');
  const [purpose, setPurpose] = useState('');
  const [applicantName, setApplicantName] = useState('');
  const [applicantPhone, setApplicantPhone] = useState('');
  const [applicantEmail, setApplicantEmail] = useState('');

  const appointments = [
    {
      id: 1,
      applicant: 'Kamal Perera',
      phone: '+94 77 123 4567',
      email: 'kamal@example.com',
      date: '2025-01-15',
      time: '09:00 AM',
      purpose: 'New Passport Application',
      branch: 'Colombo Main Office',
      status: 'confirmed',
    },
    {
      id: 2,
      applicant: 'Sita Fernando',
      phone: '+94 71 987 6543',
      email: 'sita@example.com',
      date: '2025-01-15',
      time: '10:30 AM',
      purpose: 'Document Verification',
      branch: 'Colombo Main Office',
      status: 'confirmed',
    },
    {
      id: 3,
      applicant: 'Ravi Silva',
      phone: '+94 76 555 0123',
      email: 'ravi@example.com',
      date: '2025-01-15',
      time: '02:00 PM',
      purpose: 'Passport Collection',
      branch: 'Kandy Branch',
      status: 'pending',
    },
    {
      id: 4,
      applicant: 'Nimal Jayasinghe',
      phone: '+94 75 444 9876',
      email: 'nimal@example.com',
      date: '2025-01-16',
      time: '11:00 AM',
      purpose: 'Renewal Application',
      branch: 'Colombo Main Office',
      status: 'confirmed',
    },
  ];

  const branches = [
    { id: 'colombo-main', name: 'Colombo Main Office', address: '41, Ananda Rajakaruna Mawatha, Colombo 10' },
    { id: 'kandy', name: 'Kandy Branch', address: 'Temple Street, Kandy' },
    { id: 'galle', name: 'Galle Branch', address: 'Fort, Galle' },
    { id: 'jaffna', name: 'Jaffna Branch', address: 'Hospital Road, Jaffna' },
  ];

  const timeSlots = [
    '09:00 AM', '09:30 AM', '10:00 AM', '10:30 AM', '11:00 AM', '11:30 AM',
    '02:00 PM', '02:30 PM', '03:00 PM', '03:30 PM', '04:00 PM', '04:30 PM'
  ];

  const handleBookAppointment = () => {
    if (!selectedDate || !selectedTime || !selectedBranch || !purpose || !applicantName || !applicantPhone) {
      alert('Please fill in all required fields');
      return;
    }

    const newAppointment = {
      id: appointments.length + 1,
      applicant: applicantName,
      phone: applicantPhone,
      email: applicantEmail,
      date: selectedDate,
      time: selectedTime,
      purpose,
      branch: branches.find(b => b.id === selectedBranch)?.name || '',
      status: 'pending',
    };

    alert(`Appointment booked successfully!\nReference: APT-${newAppointment.id.toString().padStart(4, '0')}\nDate: ${selectedDate}\nTime: ${selectedTime}`);
    setShowBookingForm(false);
    
    // Reset form
    setSelectedDate('');
    setSelectedTime('');
    setBranch('');
    setPurpose('');
    setApplicantName('');
    setApplicantPhone('');
    setApplicantEmail('');
  };

  const markAttendance = (appointmentId: number, status: 'arrived' | 'no-show') => {
    alert(`Appointment ${appointmentId} marked as ${status}`);
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex justify-between items-center">
        <div>
          <h1 className="text-2xl font-bold text-gray-900">Appointments</h1>
          <p className="text-gray-600">Manage appointment bookings and schedules</p>
        </div>
        <button
          onClick={() => setShowBookingForm(true)}
          className="flex items-center space-x-2 bg-blue-600 text-white px-4 py-2 rounded-lg hover:bg-blue-700 transition-colors"
        >
          <Plus className="w-4 h-4" />
          <span>Book Appointment</span>
        </button>
      </div>

      {/* Booking Form Modal */}
      {showBookingForm && (
        <div className="fixed inset-0 bg-gray-600 bg-opacity-50 flex items-center justify-center z-50">
          <div className="bg-white rounded-xl shadow-xl max-w-2xl w-full mx-4 max-h-[90vh] overflow-y-auto">
            <div className="p-6 border-b border-gray-200">
              <h2 className="text-xl font-semibold text-gray-900">Book New Appointment</h2>
            </div>
            
            <div className="p-6 space-y-6">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">Applicant Name *</label>
                  <input
                    type="text"
                    value={applicantName}
                    onChange={(e) => setApplicantName(e.target.value)}
                    className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                    placeholder="Enter full name"
                    required
                  />
                </div>
                
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">Phone Number *</label>
                  <input
                    type="tel"
                    value={applicantPhone}
                    onChange={(e) => setApplicantPhone(e.target.value)}
                    className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                    placeholder="+94 XX XXX XXXX"
                    required
                  />
                </div>
                
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">Email Address</label>
                  <input
                    type="email"
                    value={applicantEmail}
                    onChange={(e) => setApplicantEmail(e.target.value)}
                    className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                    placeholder="Enter email address"
                  />
                </div>
                
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">Purpose *</label>
                  <select
                    value={purpose}
                    onChange={(e) => setPurpose(e.target.value)}
                    className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                    required
                  >
                    <option value="">Select Purpose</option>
                    <option value="New Passport Application">New Passport Application</option>
                    <option value="Passport Renewal">Passport Renewal</option>
                    <option value="Document Verification">Document Verification</option>
                    <option value="Passport Collection">Passport Collection</option>
                    <option value="General Inquiry">General Inquiry</option>
                  </select>
                </div>
                
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">Branch *</label>
                  <select
                    value={selectedBranch}
                    onChange={(e) => setBranch(e.target.value)}
                    className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                    required
                  >
                    <option value="">Select Branch</option>
                    {branches.map(branch => (
                      <option key={branch.id} value={branch.id}>{branch.name}</option>
                    ))}
                  </select>
                </div>
                
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">Date *</label>
                  <input
                    type="date"
                    value={selectedDate}
                    onChange={(e) => setSelectedDate(e.target.value)}
                    min={new Date().toISOString().split('T')[0]}
                    className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                    required
                  />
                </div>
              </div>
              
              {selectedDate && (
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">Available Time Slots *</label>
                  <div className="grid grid-cols-3 md:grid-cols-4 gap-3">
                    {timeSlots.map(time => (
                      <button
                        key={time}
                        onClick={() => setSelectedTime(time)}
                        className={`p-3 text-sm border rounded-lg transition-colors ${
                          selectedTime === time
                            ? 'bg-blue-600 text-white border-blue-600'
                            : 'bg-white text-gray-700 border-gray-300 hover:border-blue-400'
                        }`}
                      >
                        {time}
                      </button>
                    ))}
                  </div>
                </div>
              )}
            </div>
            
            <div className="p-6 border-t border-gray-200 flex justify-end space-x-4">
              <button
                onClick={() => setShowBookingForm(false)}
                className="px-4 py-2 text-gray-600 hover:text-gray-800 transition-colors"
              >
                Cancel
              </button>
              <button
                onClick={handleBookAppointment}
                className="bg-blue-600 text-white px-6 py-2 rounded-lg hover:bg-blue-700 transition-colors"
              >
                Book Appointment
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Appointments List */}
      <div className="bg-white rounded-xl shadow-sm">
        <div className="p-6 border-b border-gray-200">
          <h2 className="text-lg font-semibold text-gray-900">
            {user?.role === 'applicant' ? 'My Appointments' : 'All Appointments'}
          </h2>
        </div>
        
        <div className="divide-y divide-gray-200">
          {appointments.map((appointment) => (
            <div key={appointment.id} className="p-6 hover:bg-gray-50 transition-colors">
              <div className="flex items-center justify-between">
                <div className="flex-1">
                  <div className="flex items-center space-x-4 mb-3">
                    <div className="flex items-center space-x-2">
                      <User className="w-4 h-4 text-gray-400" />
                      <span className="font-medium text-gray-900">{appointment.applicant}</span>
                    </div>
                    <div className="flex items-center space-x-2">
                      <Phone className="w-4 h-4 text-gray-400" />
                      <span className="text-sm text-gray-600">{appointment.phone}</span>
                    </div>
                    {appointment.email && (
                      <div className="flex items-center space-x-2">
                        <Mail className="w-4 h-4 text-gray-400" />
                        <span className="text-sm text-gray-600">{appointment.email}</span>
                      </div>
                    )}
                  </div>
                  
                  <div className="flex items-center space-x-6 text-sm text-gray-600">
                    <div className="flex items-center space-x-2">
                      <Calendar className="w-4 h-4" />
                      <span>{appointment.date}</span>
                    </div>
                    <div className="flex items-center space-x-2">
                      <Clock className="w-4 h-4" />
                      <span>{appointment.time}</span>
                    </div>
                    <div className="flex items-center space-x-2">
                      <MapPin className="w-4 h-4" />
                      <span>{appointment.branch}</span>
                    </div>
                  </div>
                  
                  <div className="mt-2">
                    <span className="text-sm font-medium text-gray-900">Purpose: </span>
                    <span className="text-sm text-gray-600">{appointment.purpose}</span>
                  </div>
                </div>
                
                <div className="flex items-center space-x-4">
                  <span className={`px-3 py-1 text-xs font-medium rounded-full ${
                    appointment.status === 'confirmed' 
                      ? 'bg-emerald-100 text-emerald-800'
                      : appointment.status === 'pending'
                      ? 'bg-amber-100 text-amber-800'
                      : 'bg-red-100 text-red-800'
                  }`}>
                    {appointment.status.charAt(0).toUpperCase() + appointment.status.slice(1)}
                  </span>
                  
                  {(user?.role === 'officer' || user?.role === 'admin') && (
                    <div className="flex space-x-2">
                      <button
                        onClick={() => markAttendance(appointment.id, 'arrived')}
                        className="p-2 text-emerald-600 hover:bg-emerald-50 rounded-lg transition-colors"
                        title="Mark as Arrived"
                      >
                        <CheckCircle className="w-4 h-4" />
                      </button>
                      <button
                        onClick={() => markAttendance(appointment.id, 'no-show')}
                        className="p-2 text-red-600 hover:bg-red-50 rounded-lg transition-colors"
                        title="Mark as No-Show"
                      >
                        <XCircle className="w-4 h-4" />
                      </button>
                    </div>
                  )}
                  
                  <div className="flex space-x-2">
                    <button className="p-2 text-gray-400 hover:text-gray-600 hover:bg-gray-100 rounded-lg transition-colors">
                      <Edit className="w-4 h-4" />
                    </button>
                    <button className="p-2 text-red-400 hover:text-red-600 hover:bg-red-50 rounded-lg transition-colors">
                      <Trash2 className="w-4 h-4" />
                    </button>
                  </div>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};

export default Appointments;