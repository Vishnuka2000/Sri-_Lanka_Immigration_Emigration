import React from 'react';
import { Plane, Import as Passport, Users, MapPin, Clock, Shield } from 'lucide-react';

const Services = () => {
  const services = [
    {
      icon: Passport,
      title: 'Passport Services',
      description: 'Apply for new passports, renewals, and replacements',
      features: ['New Passport Application', 'Passport Renewal', 'Lost/Damaged Passport', 'Express Processing'],
    },
    {
      icon: Plane,
      title: 'Visa Services',
      description: 'Tourist, business, and resident visa applications',
      features: ['Tourist Visa', 'Business Visa', 'Resident Visa', 'Transit Visa'],
    },
    {
      icon: Users,
      title: 'Immigration Services',
      description: 'Entry permits and immigration clearance',
      features: ['Entry Permits', 'Immigration Clearance', 'Deportation Appeals', 'Status Extensions'],
    },
    {
      icon: MapPin,
      title: 'Travel Advisory',
      description: 'Latest travel information and requirements',
      features: ['Country Requirements', 'Travel Alerts', 'Embassy Contacts', 'Safety Guidelines'],
    },
    {
      icon: Clock,
      title: 'Express Services',
      description: 'Fast-track processing for urgent applications',
      features: ['24-hour Processing', 'Emergency Travel', 'Priority Queue', 'Same-day Service'],
    },
    {
      icon: Shield,
      title: 'Verification Services',
      description: 'Document verification and authentication',
      features: ['Document Verification', 'Certificate Authentication', 'Background Checks', 'Security Clearance'],
    },
  ];

  return (
    <section className="py-16 bg-gray-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-12">
          <h2 className="text-3xl font-bold text-gray-900 mb-4">Our Services</h2>
          <p className="text-xl text-gray-600 max-w-3xl mx-auto">
            Comprehensive immigration and emigration services designed to meet all your travel document needs
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {services.map((service, index) => (
            <div
              key={index}
              className="bg-white rounded-xl shadow-lg hover:shadow-xl transition-shadow duration-300 overflow-hidden group"
            >
              <div className="p-6">
                <div className="flex items-center mb-4">
                  <div className="bg-gradient-to-br from-blue-500 to-emerald-500 p-3 rounded-lg">
                    <service.icon size={24} className="text-white" />
                  </div>
                  <h3 className="text-xl font-semibold text-gray-900 ml-4">{service.title}</h3>
                </div>
                
                <p className="text-gray-600 mb-6">{service.description}</p>
                
                <ul className="space-y-2">
                  {service.features.map((feature, featureIndex) => (
                    <li key={featureIndex} className="flex items-center text-gray-700">
                      <div className="w-2 h-2 bg-emerald-500 rounded-full mr-3"></div>
                      {feature}
                    </li>
                  ))}
                </ul>
                
                <button className="w-full mt-6 bg-gradient-to-r from-blue-600 to-emerald-600 text-white py-3 rounded-lg hover:from-blue-700 hover:to-emerald-700 transition-all duration-300 font-semibold group-hover:scale-105">
                  Learn More
                </button>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default Services;