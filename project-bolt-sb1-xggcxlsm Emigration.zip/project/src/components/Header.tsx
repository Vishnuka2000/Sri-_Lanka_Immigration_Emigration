import React, { useState } from 'react';
import { Menu, X, Globe, Phone, Mail } from 'lucide-react';

const Header = () => {
  const [isMenuOpen, setIsMenuOpen] = useState(false);
  const [currentLang, setCurrentLang] = useState('EN');

  const languages = ['EN', 'සි', 'த'];

  return (
    <header className="bg-white shadow-lg">
      {/* Top bar */}
      <div className="bg-blue-900 text-white py-2">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center text-sm">
            <div className="flex items-center space-x-6">
              <div className="flex items-center space-x-2">
                <Phone size={16} />
                <span>+94 11 532 9200</span>
              </div>
              <div className="flex items-center space-x-2">
                <Mail size={16} />
                <span>info@immigration.gov.lk</span>
              </div>
            </div>
            <div className="flex items-center space-x-4">
              <div className="flex items-center space-x-2">
                <Globe size={16} />
                <select 
                  value={currentLang}
                  onChange={(e) => setCurrentLang(e.target.value)}
                  className="bg-transparent border-none text-white focus:outline-none cursor-pointer"
                >
                  {languages.map(lang => (
                    <option key={lang} value={lang} className="text-blue-900">{lang}</option>
                  ))}
                </select>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Main header */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex justify-between items-center py-4">
          {/* Logo and title */}
          <div className="flex items-center space-x-4">
            <div className="w-16 h-16 bg-gradient-to-br from-blue-600 to-emerald-500 rounded-lg flex items-center justify-center">
              <span className="text-white font-bold text-xl">SL</span>
            </div>
            <div>
              <h1 className="text-2xl font-bold text-gray-900">Department of Immigration & Emigration</h1>
              <p className="text-gray-600">Democratic Socialist Republic of Sri Lanka</p>
            </div>
          </div>

          {/* Desktop navigation */}
          <nav className="hidden lg:flex space-x-8">
            <a href="#" className="text-gray-700 hover:text-blue-600 font-medium transition-colors">Home</a>
            <a href="#" className="text-gray-700 hover:text-blue-600 font-medium transition-colors">Services</a>
            <a href="#" className="text-gray-700 hover:text-blue-600 font-medium transition-colors">Applications</a>
            <a href="#" className="text-gray-700 hover:text-blue-600 font-medium transition-colors">Status Check</a>
            <a href="#" className="text-gray-700 hover:text-blue-600 font-medium transition-colors">Contact</a>
          </nav>

          {/* Mobile menu button */}
          <button
            onClick={() => setIsMenuOpen(!isMenuOpen)}
            className="lg:hidden p-2 rounded-md text-gray-400 hover:text-gray-500 hover:bg-gray-100"
          >
            {isMenuOpen ? <X size={24} /> : <Menu size={24} />}
          </button>
        </div>

        {/* Mobile navigation */}
        {isMenuOpen && (
          <div className="lg:hidden py-4 border-t border-gray-200">
            <div className="space-y-2">
              <a href="#" className="block px-4 py-2 text-gray-700 hover:bg-gray-100 rounded-md">Home</a>
              <a href="#" className="block px-4 py-2 text-gray-700 hover:bg-gray-100 rounded-md">Services</a>
              <a href="#" className="block px-4 py-2 text-gray-700 hover:bg-gray-100 rounded-md">Applications</a>
              <a href="#" className="block px-4 py-2 text-gray-700 hover:bg-gray-100 rounded-md">Status Check</a>
              <a href="#" className="block px-4 py-2 text-gray-700 hover:bg-gray-100 rounded-md">Contact</a>
            </div>
          </div>
        )}
      </div>
    </header>
  );
};

export default Header;