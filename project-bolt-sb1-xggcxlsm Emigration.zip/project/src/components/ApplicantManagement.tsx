import React, { useState } from 'react';
import { User, Phone, Mail, MapPin, FileText, Calendar, Search, Filter, Eye, CreditCard as Edit, MessageSquare, History } from 'lucide-react';

const ApplicantManagement = () => {
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedFilter, setSelectedFilter] = useState('all');
  const [selectedApplicant, setSelectedApplicant] = useState(null);

  const applicants = [
    {
      id: 1,
      name: 'Kamal Perera',
      nic: '199012345678',
      email: 'kamal@example.com',
      phone: '+94 77 123 4567',
      address: 'No. 123, Galle Road, Colombo 03',
      registrationDate: '2025-01-05',
      totalApplications: 2,
      activeApplications: 1,
      lastActivity: '2025-01-10',
      status: 'active',
      applications: [
        { ref: 'APP-2025-001234', type: 'New Passport', status: 'Under Review', date: '2025-01-10' },
        { ref: 'APP-2024-005678', type: 'Passport Renewal', status: 'Completed', date: '2024-08-15' },
      ],
      communications: [
        { date: '2025-01-10', type: 'SMS', message: 'Application received and under review' },
        { date: '2025-01-08', type: 'Email', message: 'Document verification required' },
      ]
    },
    {
      id: 2,
      name: 'Sita Fernando',
      nic: '198756789012',
      email: 'sita@example.com',
      phone: '+94 71 987 6543',
      address: 'No. 456, Kandy Road, Peradeniya',
      registrationDate: '2024-12-20',
      totalApplications: 1,
      activeApplications: 1,
      lastActivity: '2025-01-09',
      status: 'active',
      applications: [
        { ref: 'APP-2025-001235', type: 'Passport Renewal', status: 'Approved', date: '2025-01-09' },
      ],
      communications: [
        { date: '2025-01-09', type: 'Email', message: 'Passport ready for collection' },
      ]
    },
    {
      id: 3,
      name: 'Ravi Silva',
      nic: '199534567890',
      email: 'ravi@example.com',
      phone: '+94 76 555 0123',
      address: 'No. 789, Main Street, Galle',
      registrationDate: '2024-11-15',
      totalApplications: 3,
      activeApplications: 1,
      lastActivity: '2025-01-08',
      status: 'active',
      applications: [
        { ref: 'APP-2025-001236', type: 'Lost Passport', status: 'Documents Required', date: '2025-01-08' },
        { ref: 'APP-2024-003456', type: 'New Passport', status: 'Completed', date: '2024-11-20' },
        { ref: 'APP-2024-007890', type: 'Passport Renewal', status: 'Completed', date: '2024-12-05' },
      ],
      communications: [
        { date: '2025-01-08', type: 'SMS', message: 'Additional documents required' },
        { date: '2024-12-05', type: 'Email', message: 'Passport renewal completed' },
      ]
    },
    {
      id: 4,
      name: 'Nimal Jayasinghe',
      nic: '199678901234',
      email: 'nimal@example.com',
      phone: '+94 75 444 9876',
      address: 'No. 321, Temple Road, Kandy',
      registrationDate: '2024-10-10',
      totalApplications: 1,
      activeApplications: 0,
      lastActivity: '2024-12-15',
      status: 'inactive',
      applications: [
        { ref: 'APP-2024-009876', type: 'Express Passport', status: 'Completed', date: '2024-12-15' },
      ],
      communications: [
        { date: '2024-12-15', type: 'SMS', message: 'Passport delivered successfully' },
      ]
    },
  ];

  const filteredApplicants = applicants.filter(applicant => {
    const matchesSearch = applicant.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         applicant.nic.includes(searchTerm) ||
                         applicant.email.toLowerCase().includes(searchTerm.toLowerCase());
    
    const matchesFilter = selectedFilter === 'all' || applicant.status === selectedFilter;
    
    return matchesSearch && matchesFilter;
  });

  const sendMessage = (applicantId: number) => {
    const message = prompt('Enter message to send to applicant:');
    if (message) {
      alert(`Message sent to applicant: ${message}`);
    }
  };

  const viewApplicationHistory = (applicant: any) => {
    setSelectedApplicant(applicant);
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex justify-between items-center">
        <div>
          <h1 className="text-2xl font-bold text-gray-900">Applicant Management</h1>
          <p className="text-gray-600">Manage applicant profiles and communication history</p>
        </div>
      </div>

      {/* Search and Filters */}
      <div className="bg-white rounded-xl shadow-sm p-6">
        <div className="flex flex-col md:flex-row md:items-center md:justify-between space-y-4 md:space-y-0">
          <div className="flex-1 max-w-md">
            <div className="relative">
              <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-5 h-5" />
              <input
                type="text"
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="w-full pl-10 pr-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                placeholder="Search by name, NIC, or email..."
              />
            </div>
          </div>
          
          <div className="flex items-center space-x-4">
            <div className="flex items-center space-x-2">
              <Filter className="w-4 h-4 text-gray-400" />
              <select
                value={selectedFilter}
                onChange={(e) => setSelectedFilter(e.target.value)}
                className="border border-gray-300 rounded-lg px-3 py-2 text-sm focus:ring-2 focus:ring-blue-500 focus:border-transparent"
              >
                <option value="all">All Applicants</option>
                <option value="active">Active</option>
                <option value="inactive">Inactive</option>
              </select>
            </div>
          </div>
        </div>
      </div>

      {/* Statistics */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
        <div className="bg-white rounded-xl shadow-sm p-6">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm font-medium text-gray-600">Total Applicants</p>
              <p className="text-2xl font-bold text-gray-900">{applicants.length}</p>
            </div>
            <User className="w-8 h-8 text-blue-500" />
          </div>
        </div>
        
        <div className="bg-white rounded-xl shadow-sm p-6">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm font-medium text-gray-600">Active Applicants</p>
              <p className="text-2xl font-bold text-emerald-600">
                {applicants.filter(a => a.status === 'active').length}
              </p>
            </div>
            <User className="w-8 h-8 text-emerald-500" />
          </div>
        </div>
        
        <div className="bg-white rounded-xl shadow-sm p-6">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm font-medium text-gray-600">Total Applications</p>
              <p className="text-2xl font-bold text-blue-600">
                {applicants.reduce((sum, a) => sum + a.totalApplications, 0)}
              </p>
            </div>
            <FileText className="w-8 h-8 text-blue-500" />
          </div>
        </div>
        
        <div className="bg-white rounded-xl shadow-sm p-6">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm font-medium text-gray-600">Active Applications</p>
              <p className="text-2xl font-bold text-amber-600">
                {applicants.reduce((sum, a) => sum + a.activeApplications, 0)}
              </p>
            </div>
            <FileText className="w-8 h-8 text-amber-500" />
          </div>
        </div>
      </div>

      {/* Applicants List */}
      <div className="bg-white rounded-xl shadow-sm">
        <div className="p-6 border-b border-gray-200">
          <h2 className="text-lg font-semibold text-gray-900">Applicants</h2>
        </div>
        
        <div className="divide-y divide-gray-200">
          {filteredApplicants.map((applicant) => (
            <div key={applicant.id} className="p-6 hover:bg-gray-50 transition-colors">
              <div className="flex items-center justify-between">
                <div className="flex-1">
                  <div className="flex items-center space-x-4 mb-3">
                    <div className="w-12 h-12 bg-gradient-to-br from-blue-500 to-emerald-500 rounded-full flex items-center justify-center">
                      <User className="w-6 h-6 text-white" />
                    </div>
                    <div>
                      <h3 className="text-lg font-medium text-gray-900">{applicant.name}</h3>
                      <p className="text-sm text-gray-600">NIC: {applicant.nic}</p>
                    </div>
                    <span className={`px-2 py-1 text-xs font-medium rounded-full ${
                      applicant.status === 'active' 
                        ? 'bg-emerald-100 text-emerald-800'
                        : 'bg-gray-100 text-gray-800'
                    }`}>
                      {applicant.status.charAt(0).toUpperCase() + applicant.status.slice(1)}
                    </span>
                  </div>
                  
                  <div className="grid grid-cols-1 md:grid-cols-3 gap-4 text-sm text-gray-600 mb-3">
                    <div className="flex items-center space-x-2">
                      <Mail className="w-4 h-4" />
                      <span>{applicant.email}</span>
                    </div>
                    <div className="flex items-center space-x-2">
                      <Phone className="w-4 h-4" />
                      <span>{applicant.phone}</span>
                    </div>
                    <div className="flex items-center space-x-2">
                      <Calendar className="w-4 h-4" />
                      <span>Registered: {applicant.registrationDate}</span>
                    </div>
                  </div>
                  
                  <div className="flex items-center space-x-2 text-sm text-gray-600 mb-3">
                    <MapPin className="w-4 h-4" />
                    <span>{applicant.address}</span>
                  </div>
                  
                  <div className="flex items-center space-x-6 text-sm">
                    <span className="text-gray-600">
                      <span className="font-medium">Total Applications:</span> {applicant.totalApplications}
                    </span>
                    <span className="text-gray-600">
                      <span className="font-medium">Active:</span> {applicant.activeApplications}
                    </span>
                    <span className="text-gray-600">
                      <span className="font-medium">Last Activity:</span> {applicant.lastActivity}
                    </span>
                  </div>
                </div>
                
                <div className="flex items-center space-x-2 ml-6">
                  <button
                    onClick={() => viewApplicationHistory(applicant)}
                    className="p-2 text-blue-600 hover:bg-blue-50 rounded-lg transition-colors"
                    title="View History"
                  >
                    <History className="w-4 h-4" />
                  </button>
                  
                  <button
                    onClick={() => sendMessage(applicant.id)}
                    className="p-2 text-emerald-600 hover:bg-emerald-50 rounded-lg transition-colors"
                    title="Send Message"
                  >
                    <MessageSquare className="w-4 h-4" />
                  </button>
                  
                  <button
                    className="p-2 text-gray-600 hover:bg-gray-50 rounded-lg transition-colors"
                    title="Edit Profile"
                  >
                    <Edit className="w-4 h-4" />
                  </button>
                  
                  <button
                    className="p-2 text-gray-600 hover:bg-gray-50 rounded-lg transition-colors"
                    title="View Details"
                  >
                    <Eye className="w-4 h-4" />
                  </button>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Applicant Details Modal */}
      {selectedApplicant && (
        <div className="fixed inset-0 bg-gray-600 bg-opacity-50 flex items-center justify-center z-50">
          <div className="bg-white rounded-xl shadow-xl max-w-4xl w-full mx-4 max-h-[90vh] overflow-y-auto">
            <div className="p-6 border-b border-gray-200">
              <div className="flex items-center justify-between">
                <h2 className="text-xl font-semibold text-gray-900">
                  {selectedApplicant.name} - Application History
                </h2>
                <button
                  onClick={() => setSelectedApplicant(null)}
                  className="text-gray-400 hover:text-gray-600"
                >
                  ×
                </button>
              </div>
            </div>
            
            <div className="p-6">
              <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
                {/* Applications */}
                <div>
                  <h3 className="text-lg font-medium text-gray-900 mb-4">Applications</h3>
                  <div className="space-y-3">
                    {selectedApplicant.applications.map((app, index) => (
                      <div key={index} className="border border-gray-200 rounded-lg p-4">
                        <div className="flex items-center justify-between mb-2">
                          <span className="font-medium text-gray-900">{app.ref}</span>
                          <span className={`px-2 py-1 text-xs font-medium rounded-full ${
                            app.status === 'Completed' 
                              ? 'bg-emerald-100 text-emerald-800'
                              : app.status === 'Under Review'
                              ? 'bg-amber-100 text-amber-800'
                              : app.status === 'Approved'
                              ? 'bg-blue-100 text-blue-800'
                              : 'bg-red-100 text-red-800'
                          }`}>
                            {app.status}
                          </span>
                        </div>
                        <p className="text-sm text-gray-600">{app.type}</p>
                        <p className="text-xs text-gray-500">{app.date}</p>
                      </div>
                    ))}
                  </div>
                </div>
                
                {/* Communications */}
                <div>
                  <h3 className="text-lg font-medium text-gray-900 mb-4">Communication History</h3>
                  <div className="space-y-3">
                    {selectedApplicant.communications.map((comm, index) => (
                      <div key={index} className="border border-gray-200 rounded-lg p-4">
                        <div className="flex items-center justify-between mb-2">
                          <span className="text-sm font-medium text-gray-900">{comm.type}</span>
                          <span className="text-xs text-gray-500">{comm.date}</span>
                        </div>
                        <p className="text-sm text-gray-600">{comm.message}</p>
                      </div>
                    ))}
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default ApplicantManagement;